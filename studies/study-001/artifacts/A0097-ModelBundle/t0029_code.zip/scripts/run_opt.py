"""L-BFGS ensemble (package stage-1 settings: algorithm=lbfgs tol_param=1e-10 iter=20000 init=5) with the
patched model, one arm. Direct CmdStan exe calls, explicit seeds.
Usage: python run_opt.py <arm A|B> <n_runs> <seed0> <n_parallel> [init_radius] [out_suffix] [extra lbfgs args, comma-separated]
"""
import sys, os, json, time, subprocess, re
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0, ".tools"); import stan_env
W = "studies/study-001/work/T0029"
arm, n_runs, seed0, npar = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
rad = sys.argv[5] if len(sys.argv) > 5 else "5"
suf = sys.argv[6] if len(sys.argv) > 6 else ""
extra = sys.argv[7].split(",") if len(sys.argv) > 7 else []
EXE = os.path.abspath(os.environ.get("T0029_EXE", f"{W}/stan/vep_mcmc_fixed.exe"))
DATA = f"{W}/out/synth/data_arm{arm}.json"
OUT = f"{W}/out/opt_{arm}{suf}"; os.makedirs(OUT, exist_ok=True)


def one(j):
    seed = seed0 + j; csv = f"{OUT}/j{j:02d}.csv"; log = f"{OUT}/j{j:02d}.log"
    cmd = [EXE, f"id={j+1}", "optimize", "algorithm=lbfgs", "tol_param=1e-10", *extra, "iter=20000", "random", f"seed={seed}",
           "data", f"file={DATA}", f"init={rad}", "output", f"file={csv}", "refresh=100"]
    t = time.time()
    with open(log, "w") as fh:
        rc = subprocess.call(cmd, stdout=fh, stderr=subprocess.STDOUT)
    txt = open(log, errors="ignore").read()
    rec = dict(arm=arm, job=j, seed=seed, init_radius=rad, rc=rc, seconds=round(time.time() - t, 1), csv=csv,
               cmd=" ".join(cmd))
    msg = re.findall(r"(Optimization terminated[^\n]*\n[^\n]*|Line search failed[^\n]*|Maximum number of iterations[^\n]*)", txt)
    rec["termination"] = [m.strip() for m in msg[-2:]] if msg else None
    its = re.findall(r"^\s+(\d+)\s+-?[\d.e+]+\s", txt, flags=re.M)
    rec["iterations"] = int(its[-1]) if its else None
    try:
        import pandas as pd
        rec["lp__"] = float(pd.read_csv(csv, comment="#", usecols=["lp__"]).iloc[-1, 0])
    except Exception as e:
        rec["error"] = repr(e)[:300]
    json.dump(rec, open(f"{OUT}/j{j:02d}.json", "w"))
    print(json.dumps({k: rec[k] for k in rec if k != 'cmd'}), flush=True)
    return rec


t0 = time.time()
with ThreadPoolExecutor(npar) as ex:
    res = list(ex.map(one, range(n_runs)))
json.dump(res, open(f"{OUT}/summary.json", "w"), indent=1)
print("DONE", arm, suf, round(time.time() - t0), "s")
