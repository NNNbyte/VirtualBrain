"""lp (jacobian=False, same as L-BFGS lp__) of the patched model at the generating parameters, both arms."""
import sys, os, json
import numpy as np
sys.path.insert(0, ".tools"); import stan_env
import cmdstanpy
cmdstanpy.set_cmdstan_path(os.environ["CMDSTAN"])
W = "studies/study-001/work/T0029"
T = json.load(open(f"{W}/out/synth/truth.json"))
D = json.load(open(f"{W}/out/synth/data_armA.json")); eig = np.array(D['eig'])
p = dict(x0_star=(eig.T @ ((np.array(T['x0']) + 3) / 0.3)).tolist(),
         z_init_star=(eig.T @ ((np.array(T['z_init']) - 4.1) / 0.1)).tolist(), K_star=T['K'] - 1.0,
         amp_star=(T['amp'] - 0.005) / 0.01, u_star=(np.array(T['u']) - 2).tolist(),
         log_eps_sq=(np.log(T['noise']['marginal_sd']) + 3) / 0.33)
m = cmdstanpy.CmdStanModel(exe_file=f"{W}/stan/vep_mcmc_fixed.exe")
out = {a: float(m.log_prob(p, data=f"{W}/out/synth/data_arm{a}.json", jacobian=False)['lp__'].iloc[0]) for a in "AB"}
json.dump(p, open(f"{W}/out/synth/truth_params_unconstrained.json", "w"))
json.dump(out, open(f"{W}/out/lp_truth.json", "w")); print(out)
