import sys, os, time
sys.path.insert(0, ".tools"); import stan_env
import cmdstanpy
cmdstanpy.set_cmdstan_path(os.environ["CMDSTAN"])
t = time.time()
m = cmdstanpy.CmdStanModel(stan_file=sys.argv[1], cpp_options={"STAN_THREADS": False})
print("compiled", m.exe_file, round(time.time() - t, 1), "s; cmdstan", cmdstanpy.cmdstan_version())
