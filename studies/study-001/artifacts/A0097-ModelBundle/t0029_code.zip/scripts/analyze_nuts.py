"""Posterior diagnostics and planted-EZ recovery for one arm of the T0029 synthetic benchmark.
Usage: python analyze_nuts.py <arm> [min_draws]
Reads (possibly partial) CmdStan NUTS CSVs from out/nuts_<arm>/chain*.csv. Rank-normalised split R-hat and
bulk ESS (Vehtari et al. 2021) in numpy (functions reused from T0026/scripts/analyze.py), plus CmdStan
stansummary as a cross-check. Recovery is scored against out/synth/truth.json.
"""
import sys, os, json, glob, subprocess
sys.path.insert(0, ".tools"); import stan_env
import numpy as np, pandas as pd
from scipy.stats import rankdata, norm, spearmanr

W = "studies/study-001/work/T0029"
arm = sys.argv[1]; min_draws = int(sys.argv[2]) if len(sys.argv) > 2 else 20
OUT = f"{W}/out/nuts_{arm}_analysis"; os.makedirs(OUT, exist_ok=True)
T = json.load(open(f"{W}/out/synth/truth.json")); ez, pz = T['ez_index0'], T['pz_index0']
x0true = np.array(T['x0'])
D = json.load(open(f"{W}/out/synth/data_arm{arm}.json")); nn, nt, ns = D['nn'], D['nt'], D['ns']
SC, gain, Obs = np.array(D['SC']), np.array(D['gain']), np.array(D['Obs'])
lut = [l.split()[1] for l in open(".venv-model/Lib/site-packages/vep_stim/core/util/data/VepMrtrixLut.txt")
       if l.strip() and not l.startswith('#')][1:]
THR = -2.05


def read_partial(p):
    lines = [l for l in open(p) if not l.startswith('#')]
    if not lines: return pd.DataFrame()
    hdr = lines[0].strip().split(','); rows = []
    for l in lines[1:]:
        v = l.strip().split(',')
        if len(v) == len(hdr):
            try: rows.append([float(x) for x in v])
            except ValueError: pass
    return pd.DataFrame(rows, columns=hdr)


csvs = sorted(glob.glob(f"{W}/out/nuts_{arm}/chain*.csv"), key=lambda p: int(p.split('chain')[-1][:-4]))
chains = [read_partial(p) for p in csvs]
n_draws = [len(c) for c in chains]
keep = [i for i, c in enumerate(chains) if len(c) >= min_draws]
n_min = min(n_draws[i] for i in keep)
ck = [chains[i].iloc[:n_min] for i in keep]


def _z(x):
    r = rankdata(x, method='average').reshape(x.shape)
    return norm.ppf((r - 0.375) / (x.size + 0.25))


def rhat_basic(x):
    n = x.shape[1] // 2
    s = np.concatenate([x[:, :n], x[:, n:2 * n]], 0); m, n = s.shape
    B = n * s.mean(1).var(ddof=1); Wv = s.var(1, ddof=1).mean()
    return np.sqrt(((n - 1) / n * Wv + B / n) / Wv) if Wv > 0 else np.nan


def rhat_rank(x):
    return max(rhat_basic(_z(x)), rhat_basic(_z(np.abs(x - np.median(x)))))


def ess_bulk(x):
    z = _z(x); n = z.shape[1] // 2
    s = np.concatenate([z[:, :n], z[:, n:2 * n]], 0); m, n = s.shape
    acov = np.array([np.correlate(c - c.mean(), c - c.mean(), 'full')[n - 1:] / n for c in s])
    Wv = s.var(1, ddof=1).mean(); var_plus = (n - 1) / n * Wv + s.mean(1).var(ddof=1)
    rho = 1 - (Wv - acov.mean(0)) / var_plus
    t = 1; S = 0
    while t + 1 < n:
        p = rho[t] + rho[t + 1]
        if p < 0: break
        S += p; t += 2
    return m * n / max(1 + 2 * S, 1 / np.log10(m * n))


cols = [f"x0.{i+1}" for i in range(nn)] + ['K', 'amp', 'eps', 'lp__']
diag = {}
for c in cols:
    x = np.stack([ch[c].values for ch in ck])
    diag[c] = dict(rhat=float(rhat_rank(x)), ess_bulk=float(ess_bulk(x)))
rh = np.array([diag[f"x0.{i+1}"]['rhat'] for i in range(nn)])
es = np.array([diag[f"x0.{i+1}"]['ess_bulk'] for i in range(nn)])

ss = None
try:
    exe = os.path.join(os.environ["CMDSTAN"], "bin", "stansummary.exe")
    clean = []
    for i in keep:
        cp = f"{OUT}/clean_chain{i+1}.csv"; ck_i = chains[i].iloc[:n_min]; ck_i.to_csv(cp, index=False); clean.append(cp)
    r = subprocess.run([exe, f"--csv_filename={OUT}/stansummary.csv"] + clean, capture_output=True, text=True, timeout=600)
    s = pd.read_csv(f"{OUT}/stansummary.csv", comment='#', index_col=0)
    rcol = [c for c in s.columns if c.lower().startswith('r_hat') or c == 'R_hat'][0]
    xs_ = s.loc[[f"x0[{i+1}]" for i in range(nn)]] if f"x0[1]" in s.index else s.loc[[f"x0.{i+1}" for i in range(nn)]]
    ss = dict(stansummary_x0_rhat_max=float(xs_[rcol].max()), stansummary_cols=list(s.columns))
except Exception as e:
    ss = dict(error=repr(e)[:300])

allc = pd.concat(ck, ignore_index=True)
md = int(allc['treedepth__'].max())
sampler = dict(chains_used=len(keep), draws_per_chain=n_min, draws_per_chain_all=n_draws,
               divergences=int(allc['divergent__'].sum()), divergences_per_chain=[int(c['divergent__'].sum()) for c in ck],
               treedepth_mean=float(allc['treedepth__'].mean()), treedepth_max_observed=md,
               n_at_observed_max_depth=int((allc['treedepth__'] >= md).sum()),
               n_leapfrog_mean=float(allc['n_leapfrog__'].mean()),
               stepsize_per_chain=[float(c['stepsize__'].iloc[0]) for c in ck],
               accept_stat_mean=float(allc['accept_stat__'].mean()),
               lp_mean_per_chain=[float(c['lp__'].mean()) for c in ck],
               amp_mean_per_chain=[float(c['amp'].mean()) for c in ck],
               x0_rhat_max=float(np.nanmax(rh)), x0_rhat_median=float(np.nanmedian(rh)),
               x0_n_rhat_gt_1_05=int((rh > 1.05).sum()), x0_n_rhat_gt_1_01=int((rh > 1.01).sum()),
               x0_ess_bulk_min=float(np.nanmin(es)), x0_ess_bulk_median=float(np.nanmedian(es)),
               EZ_rhat=float(rh[ez]), EZ_ess_bulk=float(es[ez]),
               rhat_lp=diag['lp__']['rhat'], rhat_K=diag['K']['rhat'], rhat_amp=diag['amp']['rhat'],
               rhat_eps=diag['eps']['rhat'], ess_lp=diag['lp__']['ess_bulk'], stansummary=ss)

X0 = allc[[f"x0.{i+1}" for i in range(nn)]].values
xm = X0.mean(0); xsd = X0.std(0); pexc = (X0 > THR).mean(0)
order = np.argsort(-xm); rank_ez = int(np.where(order == ez)[0][0]) + 1
# per-draw rank of the EZ
draw_rank = (X0 > X0[:, [ez]]).sum(1) + 1
above = [int(i) for i in np.where(pexc > 0.5)[0]]
fp = [i for i in above if i != ez and i not in pz]
# per-chain EZ rank (to show between-chain agreement)
rank_chain = []
for c in ck:
    m = c[[f"x0.{i+1}" for i in range(nn)]].values.mean(0); rank_chain.append(int(np.where(np.argsort(-m) == ez)[0][0]) + 1)
rho_s = float(spearmanr(xm, x0true).correlation)
rec = dict(truth_EZ=lut[ez], truth_PZ=[lut[i] for i in pz], EZ_threshold=THR,
           EZ_rank_by_posterior_mean_x0=rank_ez, EZ_rank_per_chain=rank_chain,
           EZ_P_rank1=float((draw_rank == 1).mean()),
           EZ_x0_mean=float(xm[ez]), EZ_x0_sd=float(xsd[ez]), EZ_x0_q05_q95=[float(np.quantile(X0[:, ez], q)) for q in (.05, .95)],
           EZ_P_x0_gt_thr=float(pexc[ez]), EZ_true_x0=float(x0true[ez]),
           PZ=[dict(region=lut[i], true=float(x0true[i]), mean=float(xm[i]), sd=float(xsd[i]), P_gt_thr=float(pexc[i]),
                    rank=int(np.where(order == i)[0][0]) + 1) for i in pz],
           regions_P_gt_thr_above_0_5=[lut[i] for i in above],
           false_positives=[dict(region=lut[i], mean=float(xm[i]), P_gt_thr=float(pexc[i]), max_gain=float(np.abs(gain[:, i]).max()))
                            for i in fp],
           n_false_positives=len(fp),
           top10=[dict(region=lut[i], mean=float(xm[i]), sd=float(xsd[i]), P_gt_thr=float(pexc[i]), true=float(x0true[i]))
                  for i in order[:10]],
           K_mean=float(allc['K'].mean()), amp_mean=float(allc['amp'].mean()), eps_mean=float(allc['eps'].mean()),
           truth_K=T['K'], truth_amp=T['amp'],
           spearman_posterior_mean_vs_true_x0=rho_s,
           rmse_x0=float(np.sqrt(np.mean((xm - x0true) ** 2))))


# posterior predictive check (deterministic mean path at posterior draws, thinned)
def simulate(x0, zi, K):
    x = np.empty((nn, nt)); z = np.empty((nn, nt)); x[:, 0] = -1.98; z[:, 0] = zi; rs = SC.sum(1)
    for t in range(nt - 1):
        xt, zt = x[:, t], z[:, t]; gx = SC @ xt - rs * xt
        x[:, t + 1] = xt + 0.1 * (1 - xt ** 3 - 2 * xt ** 2 - zt + 3.1)
        z[:, t + 1] = zt + 0.1 / 15 * (4 * (xt - x0) - zt - K * gx)
    return x


idx = np.linspace(0, len(allc) - 1, min(100, len(allc))).astype(int)
logO = np.log(Obs); r2 = []; seiz = np.zeros(nn); ez_seiz = 0
Sy = np.load(f"{W}/out/synth/synth.npz"); yc = Sy['yclean']; infc = np.where(np.abs(yc - yc[10]).max(0) > 2 * T['noise']['marginal_sd'])[0]
r2i = []; r2c = []
for k in idx:
    r = allc.iloc[k]
    x0 = np.array([r[f"x0.{i+1}"] for i in range(nn)]); zi = np.array([r[f"z_init.{i+1}"] for i in range(nn)])
    u = np.array([r[f"u.{j+1}"] for j in range(ns)])
    x = simulate(x0, zi, r['K']); yh = (r['amp'] * gain @ x).T + u
    res = (logO - yh)[10:]; r2.append(1 - (res ** 2).sum() / ((logO[10:] - logO[10:].mean(0)) ** 2).sum())
    ri = res[:, infc]; oi = logO[10:, infc]; r2i.append(1 - (ri ** 2).sum() / ((oi - oi.mean(0)) ** 2).sum())
    rc = (yc - yh)[10:, infc]; r2c.append(1 - (rc ** 2).sum() / ((yc[10:, infc] - yc[10:, infc].mean(0)) ** 2).sum())
    s = (x > 0).any(1); seiz += s
rec['ppc'] = dict(n_draws=len(idx), R2_within_channel_mean=float(np.mean(r2)),
                  informative_channels=[int(c) for c in infc],
                  R2_informative_channels_vs_noisy_data=float(np.mean(r2i)),
                  R2_informative_channels_vs_noise_free_signal=float(np.mean(r2c)),
                  P_seizing_in_window={lut[i]: float(seiz[i] / len(idx)) for i in np.argsort(-seiz)[:8] if seiz[i] > 0})

pd.DataFrame(dict(region=lut, true_x0=x0true, post_mean=xm, post_sd=xsd, P_gt_thr=pexc, rhat=rh, ess_bulk=es)).to_csv(
    f"{OUT}/posterior_x0_by_region.csv", index=False)
res = dict(arm=arm, sampler=sampler, recovery=rec)
json.dump(res, open(f"{OUT}/summary.json", "w"), indent=1)
print(json.dumps(res, indent=1))
