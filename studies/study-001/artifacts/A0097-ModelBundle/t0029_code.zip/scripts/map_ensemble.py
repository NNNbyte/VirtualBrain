"""MAP-ensemble recovery table for one arm (converged L-BFGS optima).
Usage: python map_ensemble.py <arm> [opt_dir_suffix]
"""
import sys, json, glob
import numpy as np, pandas as pd
W = "studies/study-001/work/T0029"
arm = sys.argv[1]; suf = sys.argv[2] if len(sys.argv) > 2 else ""
T = json.load(open(f"{W}/out/synth/truth.json")); ez, pz = T['ez_index0'], T['pz_index0']
lut = [l.split()[1] for l in open(".venv-model/Lib/site-packages/vep_stim/core/util/data/VepMrtrixLut.txt")
       if l.strip() and not l.startswith('#')][1:]
x0true = np.array(T['x0']); nn = len(x0true)
rows = []
for p in sorted(glob.glob(f"{W}/out/opt_{arm}{suf}/j*.json")):
    o = json.load(open(p))
    if 'lp__' not in o: continue
    term = " ".join(o.get('termination') or [])
    r = pd.read_csv(o['csv'], comment='#').iloc[-1]
    x0 = np.array([r[f'x0.{i+1}'] for i in range(nn)])
    order = np.argsort(-x0); rank = int(np.where(order == ez)[0][0]) + 1
    above = [i for i in order if x0[i] > -2.05]
    fp = [i for i in above if i != ez and i not in pz]
    rows.append(dict(arm=arm, job=o['job'], seed=o['seed'], converged=('normally' in term), lp=o['lp__'],
                     iters=o.get('iterations'), K=r['K'], amp=r['amp'], eps=r['eps'], EZ_x0=x0[ez], EZ_rank=rank,
                     PZ_x0=";".join(f"{x0[i]:.2f}" for i in pz), n_above=len(above), n_FP=len(fp),
                     FP=";".join(f"{lut[i]}({x0[i]:.2f})" for i in fp),
                     top5=";".join(f"{lut[i]}({x0[i]:.2f})" for i in order[:5]),
                     rmse_x0=float(np.sqrt(np.mean((x0 - x0true) ** 2)))))
df = pd.DataFrame(rows).sort_values('lp', ascending=False)
df.to_csv(f"{W}/out/map_ensemble_{arm}{suf}.csv", index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 80)
print(df[['job', 'converged', 'lp', 'iters', 'K', 'amp', 'eps', 'EZ_x0', 'EZ_rank', 'PZ_x0', 'n_FP', 'rmse_x0', 'top5']].to_string(index=False))
