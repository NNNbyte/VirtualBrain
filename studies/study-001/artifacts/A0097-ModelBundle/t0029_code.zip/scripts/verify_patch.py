"""Check the patched Stan model against a numpy re-implementation, and the package model (T0026's compiled
GQ-free copy, model block identical to vep_stim/stan/vep_mcmc.stan) against numpy with the package's
column-major skip. Also times one log-density+gradient evaluation of each.
Usage: python verify_patch.py <data_json> <out_json>
"""
import sys, os, json, time
import numpy as np
sys.path.insert(0, ".tools"); import stan_env
import cmdstanpy
cmdstanpy.set_cmdstan_path(os.environ["CMDSTAN"])
data, outp = sys.argv[1], sys.argv[2]
D = json.load(open(data)); nn, nt, ns = D['nn'], D['nt'], D['ns']
Obs = np.array(D['Obs']); SC = np.array(D['SC']); gain = np.array(D['gain']); eig = np.array(D['eig'])
rng = np.random.default_rng(7)
p = dict(z_init_star=rng.normal(0, 1, nn).tolist(), x0_star=rng.normal(0, 1, nn).tolist(), K_star=0.3,
         amp_star=9.0, u_star=rng.normal(4, 1, ns).tolist(), log_eps_sq=3.0)


def np_lp(p, skip):
    x0 = -3 + 0.3 * eig @ np.array(p['x0_star']); zi = 4.1 + 0.1 * eig @ np.array(p['z_init_star'])
    K = 1 + p['K_star']; amp = 0.005 + 0.01 * p['amp_star']; u = 2 + np.array(p['u_star'])
    eps = np.exp(0.33 * p['log_eps_sq'] - 3)
    x = np.empty((nn, nt)); xt = np.full(nn, -1.98); zt = zi.copy(); x[:, 0] = xt; rs = SC.sum(1)
    for t in range(nt - 1):
        gx = SC @ xt - rs * xt
        xn = xt + 0.1 * (1 - xt ** 3 - 2 * xt ** 2 - zt + 3.1); zt = zt + 0.1 / 15 * (4 * (xt - x0) - zt - K * gx); xt = xn
        x[:, t + 1] = xt
    yh = (amp * gain @ x).T + u; r = (np.log(Obs) - yh)
    if skip == 'time':
        m = np.zeros((nt, ns), bool); m[10:] = True
    else:   # package: column-major vector index i (1-based) >= 10*ns+1
        m = (np.arange(nt)[:, None] + nt * np.arange(ns)[None, :]) >= 10 * ns
    ll = (-0.5 * (r[m] / eps) ** 2 - np.log(eps)).sum()
    pri = -0.5 * (np.sum(np.square(p['x0_star'])) + np.sum(np.square(p['z_init_star'])) + p['K_star'] ** 2 +
                  p['amp_star'] ** 2 + np.sum(np.square(p['u_star']))) - 0.5 * (p['log_eps_sq'] / 10) ** 2
    return ll + pri, m


res = {}
for name, exe, skip in (('patched', 'studies/study-001/work/T0029/stan/vep_mcmc_fixed.exe', 'time'),
                        ('package', 'studies/study-001/work/T0026/stan/vep_mcmc_nogq.exe', 'colmajor')):
    m = cmdstanpy.CmdStanModel(exe_file=exe)
    t = time.time(); lp = m.log_prob(p, data=data, jacobian=False); dt = time.time() - t
    stan_lp = float(lp['lp__'].iloc[0]); ref, mask = np_lp(p, skip)
    dropped_cols = [int(j) for j in range(ns) if not mask[:, j].any()]
    res[name] = dict(stan_lp=stan_lp, numpy_lp=ref, diff=stan_lp - ref, seconds_log_prob_call=round(dt, 2),
                     n_lik_terms=int(mask.sum()), fully_dropped_channels=dropped_cols,
                     time_points_dropped_for_other_channels=int((~mask[:, -1]).sum()))
# gradient timing via CmdStan diagnose (a few evaluations)
print(json.dumps(res, indent=1))
json.dump(res, open(outp, 'w'), indent=1)
