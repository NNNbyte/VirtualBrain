"""Calibrate a realistic observation-noise level for the synthetic benchmark from Wang P2 simulated SEEG
(A0067 P2_SEEG_ts_fit.npz), using the FIXED feature recipe:
  F1 true sampling rate from time_steps (8 ms -> 125 Hz) instead of the notebooks' hard-coded 250 Hz;
  F2 per-channel baseline referencing with a real data baseline (authors' P2 recipe: post-ictal segment
     1100:1300 prepended to 440:1300) instead of N(0,0.2) noise padding around a cross-channel-mean-removed
     window (which creates step artefacts on channels with DC offset);
  F3 reflect padding in seeg_log_power (package zero-pads the end).
Outputs the package's fitting target xs = log(Obs), Obs = slp_ds - min + 1, and noise statistics.
Usage: python calibrate_p2.py <P2 npz> <out_dir>
"""
import sys, os, json
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
import vep_prepare_op_fixed as vpo

npz, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
d = np.load(npz, allow_pickle=False)
seeg, ts, SC, gain = d['seeg'], d['time_steps'], d['SC'], d['gain']
sfreq = 1000.0 / float(np.median(np.diff(ts)))           # F1
IND_ON, IND_OFF, IND_BD = 440, 1100, 200                   # authors' P2 indices (mm notebook cell 10)
hpf, lpf, n_samples = 4.0, 1.0, 150                        # authors' P2 SEEG hpf/lpf
base = seeg[:, IND_OFF:IND_OFF + IND_BD]
x = np.concatenate([base, seeg[:, IND_ON:IND_OFF + IND_BD]], axis=1).T
x = x - base.T.mean(axis=0)                                # F2 per-channel baseline referencing
slp = vpo.prepare_data_feature_op(SC, x.copy(), gain, sfreq, hpf, lpf)['slp']
ds = int(slp.shape[0] / n_samples)
dfr = slp[0:-1:ds] - slp.min() + 1
xs = np.log(dfr)                                           # what the Stan likelihood sees
nb = IND_BD // ds                                          # baseline samples after downsampling
B = xs[2:nb - 2]                                           # interior of the baseline segment
sd_base = B.std(axis=0)
def ac1(v):
    v = v - v.mean(); return float((v[1:] * v[:-1]).sum() / (v * v).sum()) if (v * v).sum() > 0 else np.nan
ac = np.array([ac1(B[:, j]) for j in range(B.shape[1])])
# high-frequency residual over the whole window (first difference / sqrt2) as a second noise proxy
hf = np.diff(xs, axis=0).std(axis=0) / np.sqrt(2)
rng_ch = xs.max(0) - xs.min(0)
res = dict(sfreq_hz=sfreq, ds=ds, nt=int(xs.shape[0]), ns=int(xs.shape[1]), baseline_samples=int(nb),
           xs_min=float(xs.min()), xs_max=float(xs.max()), xs_median=float(np.median(xs)),
           xs_channel_range_quantiles={q: float(np.quantile(rng_ch, q)) for q in (0.1, 0.5, 0.9, 0.99)},
           xs_baseline_level_quantiles={q: float(np.quantile(np.median(B, 0), q)) for q in (0.1, 0.5, 0.9)},
           baseline_sd_quantiles={q: float(np.nanquantile(sd_base, q)) for q in (0.1, 0.5, 0.9)},
           baseline_lag1_ac_quantiles={q: float(np.nanquantile(ac, q)) for q in (0.1, 0.5, 0.9)},
           firstdiff_sd_quantiles={q: float(np.quantile(hf, q)) for q in (0.1, 0.5, 0.9)})
np.save(os.path.join(out, 'p2_xs_fixedpipeline.npy'), xs)
json.dump(res, open(os.path.join(out, 'calibration_p2.json'), 'w'), indent=1)
print(json.dumps(res, indent=1))
