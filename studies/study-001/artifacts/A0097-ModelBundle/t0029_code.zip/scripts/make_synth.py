"""T0029 synthetic SEEG for the vep-stim recovery benchmark.
Generative model = the Stan model's own forward model (vep_mcmc.stan): 2D Epileptor, Euler dt=0.1,
tau0=15, I1=3.1, x_init=-1.98, nt=150, coupling K*sum_j SC_ij (x_j - x_i), sensor model
log-feature y = amp * gain @ x + u, plus observation noise. Observation noise is "realistic": AR(1) in
log-feature space, phi=0.9, marginal SD 0.15, bracketed by the fixed-pipeline P2 feature statistics
(out/calib/calibration_p2.json: baseline lag-1 AC ~0.91; noise SD between first-difference-derived
~0.09 and baseline SD ~0.22). It is NOT the iid Gaussian the likelihood assumes (deliberate, mild misspecification).

EZ choice (seeded): candidates = regions with max |gain| >= 8 and >= 3 contacts above 25% of that max
(good SEEG sensitivity in P2's gain). EZ = rng.choice(candidates). PZ = the 2 strongest P2-SC neighbours
of the EZ. x0: EZ -1.6, PZ -2.1 (sub-threshold: with P2 SC weights to the EZ of 0.03-0.06 and
K=1, coupling-driven recruitment does not occur within the 150-step window; PZ drift toward the fold), other regions -3.0 + 0.15*N(0,1) (clipped at -2.5).
Usage: python make_synth.py <P2 npz> <P1 npz> <out_dir> <seed>
"""
import sys, os, json, hashlib
import numpy as np

p2, p1, out, seed = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
os.makedirs(out, exist_ok=True)
rng = np.random.default_rng(seed)
D2 = np.load(p2, allow_pickle=False); D1 = np.load(p1, allow_pickle=False)
SC2, gain, SC1 = D2['SC'].astype(float), D2['gain'].astype(float), D1['SC'].astype(float)
ns, nn = gain.shape; nt = 150
lut = [l.split()[1] for l in open(".venv-model/Lib/site-packages/vep_stim/core/util/data/VepMrtrixLut.txt")
       if l.strip() and not l.startswith('#')][1:]
assert len(lut) == nn

# --- EZ / PZ choice -------------------------------------------------------------------------
cm = np.abs(gain).max(0)
nsens = (np.abs(gain) > 0.25 * cm).sum(0)
cand = np.where((cm >= 8) & (nsens >= 3))[0]
ez = int(rng.choice(cand))
nb = np.argsort(-SC2[ez]); pz = [int(i) for i in nb if i != ez][:2]
x0 = np.clip(-3.0 + 0.15 * rng.standard_normal(nn), None, -2.5)
x0[ez] = -1.6
x0[pz] = -2.1
K, amp = 1.0, 0.10      # amp set so the best channel's clean deflection (~2.2) sits in P2's fixed-pipeline
                        # 90-99th pct channel range (2.2-3.5); NB far tail of the package amp prior, as for real P2 features
z_init = 4.1 + 0.1 * rng.standard_normal(nn)
base_level = 3.5 + 0.1 * rng.standard_normal(ns)   # P2 fixed-pipeline baseline log-feature level ~3.45-3.63
phi, sd = 0.9, 0.15


def simulate(x0, z_init, K, SC):
    x = np.empty((nn, nt)); z = np.empty((nn, nt)); x[:, 0] = -1.98; z[:, 0] = z_init; rs = SC.sum(1)
    for t in range(nt - 1):
        xt, zt = x[:, t], z[:, t]; gx = SC @ xt - rs * xt
        x[:, t + 1] = xt + 0.1 * (1 - xt ** 3 - 2 * xt ** 2 - zt + 3.1)
        z[:, t + 1] = zt + 0.1 * (1 / 15.0) * (4 * (xt - x0) - zt - K * gx)
    return x, z


x, z = simulate(x0, z_init, K, SC2)
u = base_level - amp * (gain @ x[:, 10])          # intercepts give realistic baseline levels (as real features force)
yclean = (amp * (gain @ x)).T + u                       # nt x ns
e = np.empty((nt, ns)); e[0] = sd * rng.standard_normal(ns)
for t in range(1, nt):
    e[t] = phi * e[t - 1] + sd * np.sqrt(1 - phi ** 2) * rng.standard_normal(ns)
y = yclean + e
Obs = np.exp(y)

onset = np.array([int(np.argmax(x[i] > 0)) if (x[i] > 0).any() else -1 for i in range(nn)])
seiz = np.where(onset >= 0)[0]
defl = (yclean - yclean[10]).__abs__().max(0)            # max deflection per channel after transient
U, s, Vh = np.linalg.svd(gain); eig = Vh.T
# atlas-order sanity check for arm B: P1 vs P2 SC similarity (same VEP ordering => high correlation)
iu = np.triu_indices(nn, 1)
r_sc = float(np.corrcoef(SC1[iu], SC2[iu])[0, 1])
perm = rng.permutation(nn); r_perm = float(np.corrcoef(SC1[perm][:, perm][iu], SC2[iu])[0, 1])

for arm, SC in (('A', SC2), ('B', SC1)):
    rd = dict(nn=nn, nt=nt, ns=ns, Obs=Obs.tolist(), SC=SC.tolist(), gain=gain.tolist(), eig=eig.tolist())
    json.dump(rd, open(os.path.join(out, f'data_arm{arm}.json'), 'w'))

truth = dict(seed=seed, ez_index0=ez, ez_name=lut[ez], pz_index0=pz, pz_names=[lut[i] for i in pz],
             candidates=[lut[i] for i in cand], candidate_rule="max|gain|>=8 and >=3 contacts >25% of max",
             ez_gain_max=float(cm[ez]), ez_n_sensitive_contacts=int(nsens[ez]),
             pz_SC_weights=[float(SC2[ez, i]) for i in pz], pz_SC_weights_in_P1=[float(SC1[ez, i]) for i in pz],
             K=K, amp=amp, amp_star_equiv=(amp-0.005)/0.01, u_star_equiv_quantiles=[float(np.quantile(u-2.0,q)) for q in (0,0.5,1)], noise=dict(kind='AR1 in log-feature space', phi=phi, marginal_sd=sd),
             x0=x0.tolist(), z_init=z_init.tolist(), u=u.tolist(),
             x0_star_equiv=(eig.T @ ((x0 + 3.0) / 0.3)).tolist(),
             onset_step=onset.tolist(), seizing_regions=[lut[i] for i in seiz],
             seizing_onsets={lut[i]: int(onset[i]) for i in seiz},
             n_x0_above_m2_05=int((x0 > -2.05).sum()), max_healthy_x0=float(np.sort(x0)[-4]),
             channel_max_deflection_quantiles={q: float(np.quantile(defl, q)) for q in (0.5, 0.9, 0.99, 1.0)},
             n_channels_deflection_gt_2sd=int((defl > 2 * sd).sum()),
             SC_P1_vs_P2_upper_tri_corr=r_sc, SC_corr_random_permutation=r_perm,
             Obs_sha256=hashlib.sha256(np.ascontiguousarray(Obs).tobytes()).hexdigest(), nt=nt, ns=ns, nn=nn)
json.dump(truth, open(os.path.join(out, 'truth.json'), 'w'), indent=1)
np.savez(os.path.join(out, 'synth.npz'), x=x, z=z, yclean=yclean, y=y, Obs=Obs, x0=x0, noise=e)
print(json.dumps({k: v for k, v in truth.items() if k not in ('x0', 'z_init', 'u', 'x0_star_equiv', 'onset_step')}, indent=1))
