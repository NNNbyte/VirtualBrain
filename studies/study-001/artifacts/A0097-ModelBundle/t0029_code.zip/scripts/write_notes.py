"""Write bundle_notes.json (interpretation fields) from static notes + analysis summaries."""
import json, os
import pandas as pd
W = "studies/study-001/work/T0029"
n = json.load(open(f"{W}/bundle_notes_static.json"))
A = json.load(open(f"{W}/out/nuts_A_analysis/summary.json")); B = json.load(open(f"{W}/out/nuts_B_analysis/summary.json"))
sa, ra, sb, rb = A['sampler'], A['recovery'], B['sampler'], B['recovery']
pkg = f"{W}/out/map_ensemble_A_pkgmodel.csv"
pkg_txt = None
if os.path.exists(pkg):
    d = pd.read_csv(pkg); d = d[d.converged]
    pkg_txt = (f"Unpatched package model (T0026 vep_mcmc_nogq.exe, model block identical to vep_stim/stan/vep_mcmc.stan), 10 L-BFGS starts on arm-A data, tight tol: "
               f"{len(d)} converged (1 segfault 0xC0000005 at launch, 3 line-search failures at init, 1 stopped at the time box after 9899 iterations). "
               f"Converged optima sorted by lp: EZ rank {d.EZ_rank.tolist()}, amp {[round(a, 3) for a in d.amp]}, n_FP {d.n_FP.tolist()}, lp {[round(x) for x in d.lp]} "
               f"(lp includes the 26740*log(sqrt(2*pi)) constant, so it is not comparable to the patched lp). See map_ensemble_A_pkgmodel.csv.")
n["package_model_comparison"] = pkg_txt or "unpatched package model L-BFGS on arm-A data did not finish within the time box (scalar loops ~0.2 s/gradient); see analytic note in implications"
n["convergence_checks"] = {
    "criterion": "task: arm A passes if planted EZ ranks 1st by posterior x0 with R-hat < 1.05 on all x0 (or a converged, agreeing L-BFGS ensemble if NUTS cannot finish); arm B informative",
    "arm_A_nuts": (f"FAIL. 5 of 6 chains (chain 3 crashed with exit 0xC0000005 during warmup, no draws) x 300 draws; rank-normalised split R-hat max {sa['x0_rhat_max']:.2f} "
                   f"({sa['x0_n_rhat_gt_1_05']}/162 x0 > 1.05; CmdStan stansummary max {sa['stansummary'].get('stansummary_x0_rhat_max')}); EZ R-hat {sa['EZ_rhat']:.2f}; "
                   f"lp R-hat {sa['rhat_lp']:.2f}; amp R-hat {sa['rhat_amp']:.2f}; bulk ESS min {sa['x0_ess_bulk_min']:.1f} (median {sa['x0_ess_bulk_median']:.0f}); "
                   f"divergences {sa['divergences']}; treedepth at max 8 on {sa['n_at_observed_max_depth']}/{sa['chains_used'] * sa['draws_per_chain']} draws; "
                   f"chain lp means {[round(x) for x in sa['lp_mean_per_chain']]} (chains 5-6, started from optimum j06, stay ~250 lp units lower: separate mode)."),
    "arm_A_lbfgs": ("FAIL as an agreeing ensemble. Round 2 (tight tol): 5 high-amp optima (lp 37.9-38.4k, eps at the 0.138 noise floor) rank the EZ 2nd (4) or 3rd (1), "
                    "each behind a different spurious region; 9 low-amp optima (amp at the 0.005 bound, lp ~36k) rank the EZ 1st-3rd with 8-12 FPs. "
                    "Each run converged by CmdStan criteria; they disagree."),
    "arm_B_nuts": (f"Not converged by the same rule: 6/6 chains x 300 draws, R-hat max {sb['x0_rhat_max']:.2f} ({sb['x0_n_rhat_gt_1_05']}/162 > 1.05; stansummary "
                   f"{sb['stansummary'].get('stansummary_x0_rhat_max')}); EZ R-hat {sb['EZ_rhat']:.2f}; lp R-hat {sb['rhat_lp']:.2f}; amp R-hat {sb['rhat_amp']:.2f}; "
                   f"ESS min {sb['x0_ess_bulk_min']:.1f}; divergences {sb['divergences']}; treedepth saturated on all draws."),
    "verdict_arm_A": "FAIL (convergence criterion not met; EZ is 1st by pooled posterior mean but P(rank 1)=%.2f and 2nd in 3/5 chains)" % ra['EZ_P_rank1'],
    "verdict_arm_B": "informative: EZ 1st in all 6 chains, P(rank 1)=%.2f, 2 FPs, not converged" % rb['EZ_P_rank1']}


def arm(r, passed):
    return {"EZ_rank_pooled_mean": r['EZ_rank_by_posterior_mean_x0'], "EZ_rank_per_chain": r['EZ_rank_per_chain'], "EZ_P_rank1": r['EZ_P_rank1'],
            "EZ_x0_mean_sd": [r['EZ_x0_mean'], r['EZ_x0_sd']], "EZ_x0_90pct": r['EZ_x0_q05_q95'], "EZ_x0_true": -1.6,
            "false_positives_P_x0_gt_-2.05_above_0.5": r['false_positives'], "PZ": r['PZ'], "amp_mean": r['amp_mean'], "K_mean": r['K_mean'],
            "pass": passed}


n["recovery_benchmark"] = {
    "planted": "EZ Right-Amygdala x0=-1.6 (only seizing region, onset step 80); PZ Right-Hippocampus-anterior, Right-Rhinal-cortex x0=-2.1 (sub-threshold, do not seize); amp 0.1, K 1",
    "arm_A_matching_P2_SC": arm(ra, False),
    "arm_B_template_P1_SC": arm(rb, "not applicable (informative arm)"),
    "note": ("Both arms over-estimate the extent: the sub-threshold PZ and Right-Insula-gyri-longi are estimated EZ-like (x0 -1.6 to -1.73) and seize in 100% of posterior draws, "
             "while amp is estimated at ~0.05 (half the truth). Arm B looking better than arm A is most plausibly an initialisation effect (its best L-BFGS optima happened to be "
             "EZ-first modes), not evidence that a mismatched SC helps.")}
n["identifiability"] = {
    "amplitude_vs_extent": ("amp x number of co-seizing regions is a near-flat direction: the EZ is seen by 3 contacts (max gain 8.1) that also see R-Hippocampus-anterior, "
                            "R-Rhinal-cortex and R-Insula-gyri-longi, so half the amplitude with 3-4 co-seizing neighbours reproduces the sensor data (PPC R2 0.87 on the 6 "
                            "informative channels vs data, 0.92 vs the noise-free signal) with the wrong network."),
    "offset_prior_conflict": ("u~N(2,1) and amp's half-normal prior penalise the realistic intercepts (planted u_star up to 20.5), pulling amp down and favouring regions that "
                              "seize for the whole window (they act as channel offsets). Sensitivity S1 (u_star sd 10, L-BFGS) raised amp to 0.06-0.077 and reduced co-seizing "
                              "neighbours, but the optima still disagreed (EZ rank 1-5) with spurious early/whole-window seizing regions (e.g. R-T2-anterior, gain 47.6, seizing from step 9)."),
    "x0_vs_z_init": ("x0 and z_init trade off for onset timing; low-gain regions can be fitted as seizing early (R-Insula-gyri-longi ~step 48 in some optima), absorbing "
                     "AR(1)-correlated noise that the iid likelihood treats as signal."),
    "coupling": ("K weakly identified (posterior mean %.2f in A, %.2f in B; truth 1); with P2 SC weights to the EZ of 0.03-0.06 the coupling barely shapes the data, which is "
                 "why swapping in P1 SC changed little." % (ra['K_mean'], rb['K_mean'])),
    "unobserved_regions": "Spearman(posterior mean x0, true x0) only ~0.11-0.12 over 162 regions: most regions are invisible to the 191 contacts and stay at the prior."}
n["ppc_note"] = ("Deterministic mean path at 100 thinned draws per arm; R2 within channel over all 191 channels ~0.25 because most channels carry only noise; informative "
                 "channels (clean deflection > 2 noise sd) = 11, 12, 13, 14, 81, 82.")
n["implications_for_HUP"] = [
    ("Even with the matching connectome, the correct gain, the model's own forward model and the channel-skip bug fixed, vep-stim did not meet the convergence criterion and "
     "over-estimated EZ extent (4-5 EZ-like regions for one planted EZ). Template-connectome fits of HUP patients should therefore not be used for x0 maps, EZ extent or a single "
     "'the EZ' call; at most for rank-based, ensemble-reported hypothesis generation with the multimodality shown explicitly."),
    ("The template-SC arm was not worse than the matching-SC arm here (EZ 1st in all arm-B chains): with weak SC weights and K ~0.4-0.8 the inference is driven by gain and onset "
     "timing, so SC mismatch is a second-order error next to the identifiability problems. One seed and one EZ only: this does not show that a template SC is safe in general "
     "(e.g. for EZs whose spread runs through strong SC edges)."),
    ("The package likelihood bug drops the first 10*ns likelihood terms in column-major order: here channels 0-11 entirely plus steps 1-110 of channel 12, i.e. two of the six "
     "informative EZ channels lose all or most of their onset. In this instance it did NOT change the MAP ranking (the 3 converged high-amp unpatched optima ranked the EZ 1st "
     "with 3 FPs, because channel 13 and late channel 12 still carry the EZ signal; 3 vs 5 optima is too few to compare with the patched ensemble). It is still a correctness "
     "defect whose damage depends on where informative contacts fall in the channel order; HUP fits must use the patched likelihood (P1)."),
    ("The u/amp priors must be data-centred (or features baseline-referenced) before HUP fitting; otherwise realistic feature offsets push amplitude toward its bound and create "
     "whole-window seizing artefacts."),
    ("NUTS needs a reparameterisation or a different sampler setup: every draw hit max_depth 8 (step size ~0.007-0.015); 600 iterations took ~55 min per chain here. Budget "
     "several hours per patient, start multiple chains from diverse optima, and treat R-hat > 1.05 as a hard stop.")]
n["commands"] = [
    "cd C:/Users/Pengrui/Documents/Claude/Projects/AA; P=.venv-model/Scripts/python.exe; W=studies/study-001/work/T0029; A=studies/study-001/artifacts/A0067-DatasetCard",
    "$P $W/scripts/calibrate_p2.py $A/P2_SEEG_ts_fit.npz $W/out/calib",
    "$P $W/scripts/make_synth.py $A/P2_SEEG_ts_fit.npz $A/P1_SEEG_SEEG_fit.npz $W/out/synth 20261129",
    "$P $W/scripts/compile.py $W/stan/vep_mcmc_fixed.stan   (and vep_mcmc_fixed_wideu.stan)",
    "$P $W/scripts/verify_patch.py $W/out/synth/data_armA.json $W/out/verify_patch.json   (package model block = T0026/stan/vep_mcmc_nogq.exe)",
    "$P $W/scripts/lp_truth.py",
    "$P $W/scripts/run_opt.py A 10 2900 10 ; $P $W/scripts/run_opt.py B 10 3900 10   # lbfgs tol_param=1e-10 iter=20000 init=5",
    "$P $W/scripts/run_opt.py A 16 2950 11 5 _tight tol_rel_grad=1e2,tol_rel_obj=1e1,tol_grad=1e-10 ; same for B with seed0 3950",
    "T0029_EXE=$W/stan/vep_mcmc_fixed_wideu.exe $P $W/scripts/run_opt.py A 6 5950 3 5 _wideu tol_rel_grad=1e2,tol_rel_obj=1e1,tol_grad=1e-10 ; B with seed0 6950",
    "T0029_EXE=studies/study-001/work/T0026/stan/vep_mcmc_nogq.exe $P $W/scripts/run_opt.py A 10 7950 10 5 _pkgmodel tol_rel_grad=1e2,tol_rel_obj=1e1,tol_grad=1e-10",
    "$P $W/scripts/run_nuts.py A 3 2 300 300 29029 8 0.9 ,_tight ; $P $W/scripts/run_nuts.py B 3 2 300 300 39029 8 0.9 ,_tight",
    "$P $W/scripts/map_ensemble.py <A|B> <suffix> ; $P $W/scripts/spurious.py <A|B> ; $P $W/scripts/analyze_nuts.py <A|B> 50",
    "$P $W/scripts/write_notes.py ; $P $W/scripts/build_bundle.py $W/bundle_notes.json"]
n["runtime"] = {"wall_clock": "compute ~02:12 to ~04:04 EST 2026-11-01 (about 1 h 52 min wall, under the 3 h stopping rule); two CmdStan processes segfaulted (0xC0000005) on this Windows toolchain (NUTS arm A chain 3 in warmup; one package-model L-BFGS at launch)",
                "lbfgs": "patched model ~30 ms/iteration; 400-20000 iterations, 15 s - 6.5 min per start",
                "nuts": "~55 min wall per chain (600 iterations x 255 leapfrog steps), 11 chains in parallel (~10 CPU-hours)",
                "package_model": "~0.3 s/iteration (scalar loops), ~10x slower than patched"}
json.dump(n, open(f"{W}/bundle_notes.json", "w"), indent=1)
print("ok", pkg_txt)
