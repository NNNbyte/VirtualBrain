"""NUTS chains initialised at the best distinct L-BFGS optima of one arm (package stage 2: adapt delta=0.99,
max_depth=7, chains initialised at best optima), patched GQ-free model, direct CmdStan exe calls.
Usage: python run_nuts.py <arm> <n_inits> <chains_per_init> <num_warmup> <num_samples> <seed> <max_depth> <delta> <opt_glob_suffixes comma>
"""
import sys, os, json, glob, subprocess, time
import numpy as np, pandas as pd
sys.path.insert(0, ".tools"); import stan_env
W = "studies/study-001/work/T0029"
arm = sys.argv[1]; nb, cpi, nw, nsmp, seed, md = map(int, sys.argv[2:8]); delta = sys.argv[8]
sufs = sys.argv[9].split(",")
opt = []
for s in sufs:
    for p in glob.glob(f"{W}/out/opt_{arm}{s}/j*.json"):
        o = json.load(open(p))
        if 'lp__' in o and np.isfinite(o['lp__']) and 'normally' in " ".join(o.get('termination') or []):
            o['suffix'] = s; opt.append(o)
opt.sort(key=lambda o: -o['lp__'])
best = opt[:nb]
OUT = f"{W}/out/nuts_{arm}"; os.makedirs(OUT, exist_ok=True)
D = json.load(open(f"{W}/out/synth/data_arm{arm}.json")); nn, ns = D['nn'], D['ns']
procs = []; manifest = []
for b, o in enumerate(best):
    r = pd.read_csv(o['csv'], comment='#').iloc[-1]
    init = {'x0_star': [r[f'x0_star.{i+1}'] for i in range(nn)],
            'z_init_star': [r[f'z_init_star.{i+1}'] for i in range(nn)],
            'K_star': max(r['K_star'], -1 + 1e-6), 'amp_star': max(r['amp_star'], 1e-6),
            'u_star': [r[f'u_star.{j+1}'] for j in range(ns)], 'log_eps_sq': r['log_eps_sq']}
    ip = f"{OUT}/init_b{b}.json"; json.dump(init, open(ip, 'w'))
    for c in range(cpi):
        cid = b * cpi + c + 1; csv = f"{OUT}/chain{cid}.csv"
        cmd = [os.path.abspath(f"{W}/stan/vep_mcmc_fixed.exe"), f"id={cid}", "sample", "save_warmup=0",
               f"num_warmup={nw}", f"num_samples={nsmp}", "adapt", f"delta={delta}", "algorithm=hmc", "engine=nuts",
               f"max_depth={md}", "random", f"seed={seed}", "data", f"file={W}/out/synth/data_arm{arm}.json",
               f"init={ip}", "output", f"file={csv}", "refresh=10"]
        log = open(f"{OUT}/chain{cid}.log", "w")
        procs.append(subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT))
        manifest.append(dict(arm=arm, chain_id=cid, init_from=f"opt_{arm}{o['suffix']}/j{o['job']:02d}", init_opt_lp=o['lp__'],
                             init_amp=float(r['amp']), seed=seed, cmd=" ".join(cmd)))
json.dump(manifest, open(f"{OUT}/manifest.json", "w"), indent=1)
print(json.dumps(manifest, indent=1)[:2000], flush=True)
t = time.time()
for p in procs: p.wait()
print("NUTS done", arm, round(time.time() - t), "s; return codes", [p.returncode for p in procs])
