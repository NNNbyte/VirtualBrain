"""Assemble the T0029 ModelBundle payload (both arms) from out/ results.
Usage: python build_bundle.py <notes_json>
notes_json holds the hand-written interpretation fields (verdicts, implications, deviations).
"""
import sys, json, glob, os, hashlib
import pandas as pd
W = "studies/study-001/work/T0029"
notes = json.load(open(sys.argv[1]))
T = json.load(open(f"{W}/out/synth/truth.json"))
calib = json.load(open(f"{W}/out/calib/calibration_p2.json"))
verify = json.load(open(f"{W}/out/verify_patch.json"))
lp_truth = json.load(open(f"{W}/out/lp_truth.json"))


def ens(arm, suf):
    p = f"{W}/out/map_ensemble_{arm}{suf}.csv"
    if not os.path.exists(p): return None
    df = pd.read_csv(p)
    keep = ['job', 'seed', 'converged', 'lp', 'iters', 'K', 'amp', 'eps', 'EZ_x0', 'EZ_rank', 'PZ_x0', 'n_FP', 'rmse_x0', 'top5']
    return df[keep].to_dict(orient='records')


nuts = {a: json.load(open(f"{W}/out/nuts_{a}_analysis/summary.json")) for a in "AB"
        if os.path.exists(f"{W}/out/nuts_{a}_analysis/summary.json")}
man = {a: json.load(open(f"{W}/out/nuts_{a}/manifest.json")) for a in "AB"}
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()

payload = {
 "model_family": "vep-stim (Wang et al. 2025 VBT_INS_Stimulation) 2D-Epileptor network, Bayesian inversion of SEEG log-power features (vep_mcmc.stan, patched copy) - synthetic recovery benchmark",
 "implementation_versions": {
  "vep_stim": "0.1.0a1 @ 5367ef4afb976271ecc6297b70a95dd3d944af61 (installed package NOT modified; patched copies in work/T0029)",
  "stan_model": "work/T0029/stan/vep_mcmc_fixed.stan (sha256 " + sha(f"{W}/stan/vep_mcmc_fixed.stan") + ")",
  "stan_model_sensitivity": "work/T0029/stan/vep_mcmc_fixed_wideu.stan (sha256 " + sha(f"{W}/stan/vep_mcmc_fixed_wideu.stan") + ")",
  "package_stan_model_sha256": sha(f"{W}/pkg_orig/vep_mcmc.stan"),
  "cmdstan": "2.40.0 (conda-forge toolchain via .tools/stan_env.py)", "python": ".venv-model (see pip_freeze.txt)",
  "patches": notes["patches"]},
 "consumed_case": {"case_id": "SYN-P2", "network_hypothesis_set": "A0096-NetworkHypothesisSet",
                   "inputs": "A0067-DatasetCard P2_SEEG_ts_fit.npz (SC, gain; P2 SEEG only for noise calibration) and P1_SEEG_SEEG_fit.npz (SC only, arm B)",
                   "truth_file": "truth.json (attached)"},
 "hypotheses": ["H1-planted", "H2-alternative-EZ-elsewhere", "H3-mesiotemporal-blur", "H4-offset-artefact"],
 "fitting_partitions": {"note": "Synthetic single-seizure case; no cohort split, no reserved outcomes. Whole simulated window (150 steps; first 10 excluded from the likelihood) used for fitting in both arms.",
                        "arm_A": "SC = P2 (generating SC), gain = P2", "arm_B": "SC = P1 template (same VEP atlas), gain = P2",
                        "identical_data": "both arms fit the identical Obs matrix (sha256 " + T['Obs_sha256'] + ")"},
 "observation_model": {
  "fit": "log(Obs[t,s]) ~ Normal(amp*(gain@x)[s,t] + u[s], eps), t = 11..150 (patched: first 10 time points skipped for every channel)",
  "generating": "log-feature = amp*(gain@x) + u + AR(1) noise (phi 0.9, marginal sd 0.15; realised sd 0.146) - iid assumption of the fit is deliberately violated",
  "noise_calibration": calib,
  "planted": {k: T[k] for k in ('seed', 'ez_name', 'ez_index0', 'pz_names', 'pz_index0', 'K', 'amp', 'amp_star_equiv', 'u_star_equiv_quantiles', 'noise', 'seizing_onsets', 'channel_max_deflection_quantiles', 'n_channels_deflection_gt_2sd', 'SC_P1_vs_P2_upper_tri_corr', 'pz_SC_weights', 'pz_SC_weights_in_P1')},
  "lp_at_truth_jacobian_false": lp_truth},
 "parameters_or_posterior": {
  "nuts": {a: nuts[a]['recovery'] for a in nuts},
  "lbfgs_ensemble": {"A_round1_package_tol": ens('A', ''), "A_round2_tight_tol": ens('A', '_tight'),
                     "B_round1_package_tol": ens('B', ''), "B_round2_tight_tol": ens('B', '_tight'),
                     "A_sensitivity_wide_u_prior": ens("A", "_wideu"), "B_sensitivity_wide_u_prior": ens("B", "_wideu"),
                     "A_unpatched_package_model": ens("A", "_pkgmodel"), "package_model_comparison": notes.get("package_model_comparison")},
  "files": "posterior_x0_by_region_arm{A,B}.csv, map_ensemble_*.csv (attached)"},
 "numerical_diagnostics": {"patch_verification": verify, "nuts_sampler": {a: nuts[a]['sampler'] for a in nuts},
                           "nuts_manifest": man},
 "convergence_checks": notes["convergence_checks"],
 "predictive_checks": {a: nuts[a]['recovery'].get('ppc') for a in nuts} | {"note": notes.get("ppc_note")},
 "recovery_benchmark": notes["recovery_benchmark"],
 "identifiability": notes["identifiability"],
 "intended_use": "pipeline qualification benchmark only (synthetic virtual patient; not a clinical prediction, not evidence about Wang P1/P2 or any HUP patient; a fitted posterior is not a calibrated probability of seizure freedom)",
 "implications_for_HUP": notes["implications_for_HUP"],
 "deviations_from_package_recipe": notes["deviations"],
 "environment_manifest": {
  "env_digest_sha256_pip_freeze": sha(f"{W}/attach/pip_freeze.txt"), "pip_freeze_file": "attached pip_freeze.txt",
  "cwd": "C:/Users/Pengrui/Documents/Claude/Projects/AA", "commands": notes["commands"],
  "seeds": {"synthetic": 20261129, "lbfgs_A_round1": "2900+j", "lbfgs_B_round1": "3900+j", "lbfgs_A_round2": "2950+j",
            "lbfgs_B_round2": "3950+j", "lbfgs_A_wideu": "5950+j", "lbfgs_B_wideu": "6950+j", "nuts_A": 29029, "nuts_B": 39029},
  "runtime": notes["runtime"]}
}
json.dump(payload, open(f"{W}/modelbundle_payload.json", "w"), indent=1, default=str)
print("written", os.path.getsize(f"{W}/modelbundle_payload.json"), "bytes")
