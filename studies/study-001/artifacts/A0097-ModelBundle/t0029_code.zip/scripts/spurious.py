"""Characterise the top non-EZ region in each high-amp L-BFGS optimum: gain visibility, z_init, seizure timing."""
import sys, json, glob
import numpy as np, pandas as pd
W = "studies/study-001/work/T0029"; arm = sys.argv[1]
T = json.load(open(f"{W}/out/synth/truth.json")); ez = T['ez_index0']
D = json.load(open(f"{W}/out/synth/data_arm{arm}.json")); nn, nt, ns = D['nn'], D['nt'], D['ns']
SC, gain = np.array(D['SC']), np.array(D['gain'])
lut = [l.split()[1] for l in open(".venv-model/Lib/site-packages/vep_stim/core/util/data/VepMrtrixLut.txt") if l.strip() and not l.startswith('#')][1:]
cm = np.abs(gain).max(0)
def sim(x0, zi, K):
    x = np.empty((nn, nt)); z = np.empty((nn, nt)); x[:, 0] = -1.98; z[:, 0] = zi; rs = SC.sum(1)
    for t in range(nt - 1):
        xt, zt = x[:, t], z[:, t]; gx = SC @ xt - rs * xt
        x[:, t + 1] = xt + 0.1 * (1 - xt ** 3 - 2 * xt ** 2 - zt + 3.1); z[:, t + 1] = zt + 0.1 / 15 * (4 * (xt - x0) - zt - K * gx)
    return x
for p in sorted(glob.glob(f"{W}/out/opt_{arm}*/j*.json")):
    o = json.load(open(p))
    if 'normally' not in " ".join(o.get('termination') or []): continue
    r = pd.read_csv(o['csv'], comment='#').iloc[-1]
    if r['amp'] < 0.02: continue
    x0 = np.array([r[f'x0.{i+1}'] for i in range(nn)]); zi = np.array([r[f'z_init.{i+1}'] for i in range(nn)])
    x = sim(x0, zi, r['K']); on = [int(np.argmax(x[i] > 0)) if (x[i] > 0).any() else -1 for i in range(nn)]
    top = [i for i in np.argsort(-x0) if x0[i] > -2.05 and i != ez][:4]
    print(p.replace(chr(92),'/').split('out/')[-1], 'lp', round(o['lp__']), 'EZ onset', on[ez], '| ' + "; ".join(f"{lut[i]} x0={x0[i]:.2f} zi={zi[i]:.2f} onset={on[i]} gmax={cm[i]:.2f} xmax={x[i].max():.2f}" for i in top))
