// T0029 SENSITIVITY VARIANT S1 of vep_mcmc_fixed.stan: only change = u_star prior sd 1 -> 10 (channel offsets effectively unconstrained).
// T0029 patched copy of vep_stim/stan/vep_mcmc.stan (vep-stim 0.1.0a1 @5367ef4).
// Same data, parameters, priors, transformed parameters and ODE as the package model.
// Patches (see ../patches/vep_mcmc.stan.diff):
//  P1 (bug)  likelihood: the package loops i in (10*ns+1):(nt*ns) over the COLUMN-MAJOR vector
//            to_vector(xhat2[nt,ns]), which drops the first ~10*ns/nt CHANNELS (all time points)
//            instead of the first 10 TIME POINTS. Fixed: drop rows 1..10 (time) for every channel.
//  P2 (perf) Euler integration and sensor projection vectorised:
//            gx_i = sum_j SC[i,j]*(x_j - x_i) = (SC*x)_i - rowsum(SC)_i * x_i  (algebraically identical).
//  P3 (perf) generated quantities removed (recomputed in numpy from draws; posterior unchanged).
data {
  int nn;
  int nt;
  int ns;
  matrix[nt, ns] Obs;
  matrix[nn, nn] SC;
  matrix[ns, nn] gain;
  matrix[nn, nn] eig;
}

transformed data {
  real dt = 0.1;
  real tau0 = 15.0;
  real I1 = 3.1;
  real Ks = 1.0;
  int nskip = 10;
  vector[nn] x_init = rep_vector(-1.98, nn);
  vector[nn] SCrow = SC * rep_vector(1.0, nn);
  matrix[nt, ns] logObs = log(Obs);
  vector[(nt - nskip) * ns] xs = to_vector(logObs[(nskip + 1):nt, ]);
}

parameters {
  vector[nn] z_init_star;
  vector[nn] x0_star;
  real<lower=-1.0> K_star;
  real<lower=0.0> amp_star;
  vector[ns] u_star;
  real log_eps_sq;
}

transformed parameters {
  vector[nn] x0;
  vector[nn] z_init;
  real K;
  real amp;
  vector[ns] u;
  real eps;
  x0 = -3.0 + 0.30 * eig * x0_star;
  z_init = 4.1 + 0.1 * eig * z_init_star;
  K = Ks + 1.0 * K_star;
  amp = 0.005 + 0.01 * amp_star;
  u = 2.0 + 1.0 * u_star;
  eps = exp(0.33 * log_eps_sq - 3.0);
}

model {
  matrix[nn, nt] x;
  vector[nn] xt;
  vector[nn] zt;
  vector[nn] gx;
  matrix[nt, ns] xhat2;

  x0_star ~ normal(0., 1.);
  amp_star ~ normal(0., 1.);
  K_star ~ normal(0., 1.);
  log_eps_sq ~ normal(0., 10.0);
  u_star ~ normal(0., 10.0);   // SENSITIVITY S1 (not a defect fix): package prior N(0,1) widened to N(0,10)
  z_init_star ~ normal(0, 1.);

  xt = x_init;
  zt = z_init;
  x[, 1] = xt;
  for (t in 1:(nt - 1)) {
    vector[nn] xn;
    gx = SC * xt - SCrow .* xt;
    xn = xt + dt * (1.0 - xt .* xt .* xt - 2.0 * xt .* xt - zt + I1);
    zt = zt + dt * ((1 / tau0) * (4 * (xt - x0) - zt - K * gx));
    xt = xn;
    x[, t + 1] = xt;
  }
  xhat2 = amp * (gain * x)' + rep_matrix(u', nt);
  xs ~ normal(to_vector(xhat2[(nskip + 1):nt, ]), eps);
}
