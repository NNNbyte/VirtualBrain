"""Posterior diagnostics, posterior predictive checks and EZ recovery for the VBT-P1 benchmark.
Usage: python analyze.py <out_dir> <csv1> [<csv2> ...]
Reads (possibly partial) CmdStan NUTS CSVs of vep_mcmc_nogq, re-simulates the deterministic
2D-Epileptor network (identical Euler scheme to vep_mcmc.stan) to get x(t), EVs and PPC.
"""
import sys, os, json, subprocess, io
sys.path.insert(0, ".tools"); import stan_env  # CMDSTAN + DLL PATH
import numpy as np, pandas as pd
from scipy.stats import spearmanr, rankdata

W = "studies/study-001/work/T0026"
out_dir = sys.argv[1]; csvs = sys.argv[2:]
os.makedirs(out_dir, exist_ok=True)
D = json.load(open(f"{W}/out/feat/datafeatures.json"))
nn, nt, ns = D['nn'], D['nt'], D['ns']
SC, gain, Obs = np.array(D['SC']), np.array(D['gain']), np.array(D['Obs'])
lut = [l.split()[1] for l in open(".venv-model/Lib/site-packages/vep_stim/core/util/data/VepMrtrixLut.txt")
       if l.strip() and not l.startswith('#')][1:]
assert len(lut) == nn
TRUE = ['Left-O2']; iO2 = lut.index('Left-O2')


def read_partial(p):
    lines = [l for l in open(p) if not l.startswith('#')]
    hdr = lines[0].strip().split(','); rows = []
    for l in lines[1:]:
        v = l.strip().split(',')
        if len(v) == len(hdr):
            try: rows.append([float(x) for x in v])
            except ValueError: pass
    return pd.DataFrame(rows, columns=hdr)


chains = [read_partial(p) for p in csvs]
n_draws = [len(c) for c in chains]
keep = [i for i, c in enumerate(chains) if len(c) >= 20]
n_min = min(n_draws[i] for i in keep)
chains_k = [chains[i].iloc[:n_min] for i in keep]
print("draws per chain", n_draws, "using", len(keep), "chains x", n_min)

# clean copies for stansummary
clean = []
for i in keep:
    p = csvs[i]; cp = f"{out_dir}/clean_chain{i}.csv"
    hdr_comments = [l for l in open(p) if l.startswith('#')]
    with open(cp, 'w') as fh:
        fh.writelines([l for l in hdr_comments if 'Adaptation' in l or 'Step size' in l or 'Diagonal' in l][:0])
        chains[i].iloc[:n_min].to_csv(fh, index=False)
    clean.append(cp)


# ---- split R-hat (rank-normalised, Vehtari 2021) and bulk ESS in numpy ----
def _z(x):
    r = rankdata(x, method='average').reshape(x.shape)
    from scipy.stats import norm
    return norm.ppf((r - 0.375) / (x.size + 0.25))


def rhat_basic(x):  # x: chains x draws
    n = x.shape[1] // 2
    s = np.concatenate([x[:, :n], x[:, n:2 * n]], 0)
    m, n = s.shape
    B = n * s.mean(1).var(ddof=1); Wv = s.var(1, ddof=1).mean()
    return np.sqrt(((n - 1) / n * Wv + B / n) / Wv) if Wv > 0 else np.nan


def rhat_rank(x):
    return max(rhat_basic(_z(x)), rhat_basic(_z(np.abs(x - np.median(x)))))


def ess_bulk(x):
    z = _z(x); n = z.shape[1] // 2
    s = np.concatenate([z[:, :n], z[:, n:2 * n]], 0); m, n = s.shape
    acov = np.array([np.correlate(c - c.mean(), c - c.mean(), 'full')[n - 1:] / n for c in s])
    Wv = s.var(1, ddof=1).mean(); var_plus = (n - 1) / n * Wv + s.mean(1).var(ddof=1)
    rho = 1 - (Wv - acov.mean(0)) / var_plus
    t = 1; S = 0
    while t + 1 < n:
        p = rho[t] + rho[t + 1]
        if p < 0: break
        S += p; t += 2
    tau = 1 + 2 * S  # Geyer initial positive sequence (pairs from lag 1)
    tau = max(tau, 1 / np.log10(m * n))
    return m * n / tau


par_cols = [f"x0.{i+1}" for i in range(nn)] + ['K', 'amp', 'eps', 'lp__']
diag = {}
for c in par_cols:
    x = np.stack([ch[c].values for ch in chains_k])
    diag[c] = dict(rhat=float(rhat_rank(x)), ess_bulk=float(ess_bulk(x)))
rh = np.array([diag[f"x0.{i+1}"]['rhat'] for i in range(nn)])
es = np.array([diag[f"x0.{i+1}"]['ess_bulk'] for i in range(nn)])

# stansummary (CmdStan's own R-hat/ESS) as cross-check
ss_txt = None
try:
    exe = os.path.join(os.environ.get("CMDSTAN", r"C:\Users\Pengrui\.mm\envs\cs\Library\bin\cmdstan"), "bin", "stansummary.exe")
    r = subprocess.run([exe, f"--csv_filename={out_dir}/stansummary.csv"] + clean, capture_output=True, text=True, timeout=600)
    ss_txt = r.stdout[-3000:] + r.stderr[-1000:]
except Exception as e:
    ss_txt = repr(e)

allc = pd.concat(chains_k, ignore_index=True)
sampler = dict(
    chains_used=len(keep), draws_per_chain=n_min, draws_per_chain_all=n_draws,
    divergences=int(allc['divergent__'].sum()) if 'divergent__' in allc else None,
    divergences_per_chain=[int(c['divergent__'].sum()) for c in chains_k],
    treedepth_mean=float(allc['treedepth__'].mean()), treedepth_max_hits=int((allc['treedepth__'] >= 7).sum()),
    n_leapfrog_mean=float(allc['n_leapfrog__'].mean()),
    stepsize_per_chain=[float(c['stepsize__'].iloc[0]) for c in chains_k],
    accept_stat_mean=float(allc['accept_stat__'].mean()),
    lp_mean_per_chain=[float(c['lp__'].mean()) for c in chains_k],
    x0_rhat_max=float(np.nanmax(rh)), x0_rhat_median=float(np.nanmedian(rh)),
    x0_n_rhat_gt_1_05=int((rh > 1.05).sum()), x0_n_rhat_gt_1_01=int((rh > 1.01).sum()),
    x0_ess_bulk_min=float(np.nanmin(es)), x0_ess_bulk_median=float(np.nanmedian(es)),
    rhat_lp=diag['lp__']['rhat'], rhat_K=diag['K']['rhat'], rhat_amp=diag['amp']['rhat'], rhat_eps=diag['eps']['rhat'],
    ess_lp=diag['lp__']['ess_bulk'])

# ---- recovery from x0 ----
X0 = allc[[f"x0.{i+1}" for i in range(nn)]].values
x0_mean = X0.mean(0); x0_sd = X0.std(0)
p_exc = (X0 > -2.05).mean(0)
order = np.argsort(-x0_mean)
rank_O2_x0 = int(np.where(order == iO2)[0][0]) + 1


# ---- re-simulate (identical Euler scheme as vep_mcmc.stan) for EV + PPC ----
def simulate(x0, zi, K):
    dt, tau0, I1 = 0.1, 15.0, 3.1
    x = np.empty((nn, nt)); z = np.empty((nn, nt)); x[:, 0] = -1.98; z[:, 0] = zi
    rs = SC.sum(1)
    for t in range(nt - 1):
        xt, zt = x[:, t], z[:, t]
        gx = SC @ xt - rs * xt
        x[:, t + 1] = xt + dt * (1.0 - xt ** 3 - 2.0 * xt ** 2 - zt + I1)
        z[:, t + 1] = zt + dt * (1 / tau0) * (4 * (xt - x0) - zt - K * gx)
    return x


rng = np.random.default_rng(777)
idx = rng.choice(len(allc), size=min(400, len(allc)), replace=False)
EV = []; resid = []; cover = []; yhat_mean = np.zeros((nt, ns)); ok_onsets = []
logObs = np.log(Obs)
for k in idx:
    r = allc.iloc[k]
    x0 = r[[f"x0.{i+1}" for i in range(nn)]].values; zi = r[[f"z_init.{i+1}" for i in range(nn)]].values
    u = r[[f"u.{i+1}" for i in range(ns)]].values
    x = simulate(x0, zi, r['K'])
    yh = (r['amp'] * (gain @ x)).T + u
    yhat_mean += yh / len(idx)
    yrep = yh + rng.normal(0, r['eps'], size=yh.shape)
    cover.append(yrep)
    on = np.array([np.argmax(x[i] > 0) if (x[i] > 0).any() else 200 for i in range(nn)], float)
    ok_onsets.append(on)
    t0 = on.min(); ev = -np.log(((on - t0) + 1) / 20.)
    ev = (ev - ev.min()) / (ev.max() - ev.min()) if ev.max() > ev.min() else np.zeros(nn)
    EV.append(ev)
EV = np.array(EV); ON = np.array(ok_onsets); cover = np.array(cover)
ev_med = np.median(EV, 0); ev_mean = EV.mean(0)
order_ev = np.lexsort((-x0_mean, -ev_mean))
rank_O2_ev = int(np.where(order_ev == iO2)[0][0]) + 1
seizing_frac = (ON < 200).mean(0)

lo, hi = np.percentile(cover, [5, 95], axis=0)
# vep_mcmc.stan likelihood skips the first 10*ns elements of the column-major vector (= first ~10 channels)
mask = (np.arange(nt)[:, None] + nt * np.arange(ns)[None, :]) >= 10 * ns
cov90 = float(((logObs >= lo) & (logObs <= hi))[mask].mean())
res = (logObs - yhat_mean)[mask]
ss_tot = ((logObs[mask] - logObs[mask].mean()) ** 2).sum()
r2 = float(1 - (res ** 2).sum() / ss_tot)
ch_corr = np.array([np.corrcoef(logObs[:, j], yhat_mean[:, j])[0, 1] if (logObs[:, j].std() > 0 and yhat_mean[:, j].std() > 0) else np.nan for j in range(ns)])
# top-varying channels (seizure channels)
var_ch = logObs.std(0); topch = np.argsort(-var_ch)[:20]
ppc = dict(rmse_log_features=float(np.sqrt((res ** 2).mean())), R2_log_features=r2,
           coverage_90pct_predictive_interval=cov90,
           channel_corr_median=float(np.nanmedian(ch_corr)),
           channel_corr_top20_most_variable_median=float(np.nanmedian(ch_corr[topch])),
           eps_posterior_mean=float(allc['eps'].mean()), n_ppc_draws=int(len(idx)),
           likelihood_mask="column-major index >= 10*ns (package model skips first ~10 channels, not first 10 time points)", note="Features = log of envelope features the model was fit to (in-sample PPC; no held-out seizure exists for this simulated case)")
np.save(f"{out_dir}/ppc_yhat_mean.npy", yhat_mean)

# ---- hypothesis checks ----
gsum = gain.sum(0)
rho_gain = spearmanr(x0_mean, gsum)
top_gain = [lut[i] for i in np.argsort(-gsum)[:5]]
prior_sd = 0.30
contraction = 1 - (x0_sd / prior_sd) ** 2
authors = pd.read_excel(f"{W}/repo_nb/Patient1_SEEG_stimulation.xlsx")
auth_cmp = []
for reg in authors.columns:
    i = lut.index(reg)
    auth_cmp.append(dict(region=reg, authors_EV_median=float(authors[reg].median()), ours_EV_median=float(ev_med[i]),
                         ours_EV_mean=float(ev_mean[i]), ours_x0_mean=float(x0_mean[i]), ours_P_x0_gt_m2_05=float(p_exc[i])))
rho_auth = spearmanr([a['authors_EV_median'] for a in auth_cmp], [a['ours_EV_mean'] for a in auth_cmp])

table = pd.DataFrame(dict(region=lut, x0_mean=x0_mean, x0_sd=x0_sd, x0_q05=np.percentile(X0, 5, 0),
                          x0_q95=np.percentile(X0, 95, 0), P_x0_gt_m2_05=p_exc, EV_mean=ev_mean, EV_median=ev_med,
                          frac_draws_seizing=seizing_frac, onset_median=np.median(ON, 0), rhat=rh, ess_bulk=es,
                          gain_colsum=gsum, prior_contraction=contraction))
table['rank_x0'] = rankdata(-x0_mean, method='min').astype(int)
table.sort_values('x0_mean', ascending=False).to_csv(f"{out_dir}/posterior_x0_EV_by_region.csv", index=False)

exceed = [lut[i] for i in range(nn) if p_exc[i] > 0.5]
top10 = [dict(region=lut[i], x0_mean=round(float(x0_mean[i]), 3), x0_sd=round(float(x0_sd[i]), 3),
              P_x0_gt_m2_05=round(float(p_exc[i]), 3), EV_mean=round(float(ev_mean[i]), 3)) for i in order[:10]]
recovery = dict(
    truth=TRUE, rank_true_EZ_by_x0_mean=rank_O2_x0, rank_true_EZ_by_EV_mean=rank_O2_ev,
    O2=dict(x0_mean=float(x0_mean[iO2]), x0_sd=float(x0_sd[iO2]), P_x0_gt_m2_05=float(p_exc[iO2]),
            EV_mean=float(ev_mean[iO2]), EV_median=float(ev_med[iO2]), frac_draws_seizing=float(seizing_frac[iO2])),
    regions_P_x0_gt_m2_05_above_0_5=exceed,
    n_regions_P_x0_gt_m2_05_above_0_5=len(exceed),
    true_positive=[r for r in exceed if r in TRUE], false_positive=[r for r in exceed if r not in TRUE],
    top10_by_x0_mean=top10,
    top10_by_EV_mean=[dict(region=lut[i], EV_mean=round(float(ev_mean[i]), 3)) for i in order_ev[:10]],
    H4_spearman_x0mean_vs_gain_colsum=dict(rho=float(rho_gain.statistic), p=float(rho_gain.pvalue)),
    H4_top5_gain_regions=top_gain,
    H0_prior_contraction=dict(median=float(np.median(contraction)), O2=float(contraction[iO2]),
                              n_regions_contraction_gt_0_5=int((contraction > 0.5).sum())),
    authors_xlsx_comparison=auth_cmp,
    spearman_authors_EVmedian_vs_ours_EVmean_10regions=dict(rho=float(rho_auth.statistic), p=float(rho_auth.pvalue)))

summary = dict(sampler=sampler, recovery=recovery, ppc=ppc)
json.dump(summary, open(f"{out_dir}/summary.json", "w"), indent=1)
open(f"{out_dir}/stansummary_stdout.txt", "w").write(ss_txt or "")
print(json.dumps(summary, indent=1)[:6000])
