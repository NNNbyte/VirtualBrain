"""MAP-ensemble recovery table across converged L-BFGS optima (multi-start = authors' stage 1).
Usage: python map_ensemble.py <opt_dir> <feat_dir> <out_csv>
"""
import sys, json, glob
import numpy as np, pandas as pd
opt_dir, feat_dir, out_csv = sys.argv[1:4]
D = json.load(open(f"{feat_dir}/datafeatures.json"))
nn, nt, ns = D['nn'], D['nt'], D['ns']; SC = np.array(D['SC']); gain = np.array(D['gain']); logObs = np.log(np.array(D['Obs']))
lut = [l.split()[1] for l in open(".venv-model/Lib/site-packages/vep_stim/core/util/data/VepMrtrixLut.txt")
       if l.strip() and not l.startswith('#')][1:]
iO2 = lut.index('Left-O2')
# vep_mcmc.stan likelihood loops i in (10*ns+1):(nt*ns) over the COLUMN-MAJOR vector => skips the first 10*ns
# elements = first ~10 channels (all time points), not the first 10 time points.
LIK = (np.arange(nt)[:, None] + nt * np.arange(ns)[None, :]) >= 10 * ns


def simulate(x0, zi, K):
    x = np.empty((nn, nt)); z = np.empty((nn, nt)); x[:, 0] = -1.98; z[:, 0] = zi; rs = SC.sum(1)
    for t in range(nt - 1):
        xt, zt = x[:, t], z[:, t]; gx = SC @ xt - rs * xt
        x[:, t + 1] = xt + 0.1 * (1 - xt ** 3 - 2 * xt ** 2 - zt + 3.1)
        z[:, t + 1] = zt + 0.1 / 15.0 * (4 * (xt - x0) - zt - K * gx)
    return x


rows = []
for p in sorted(glob.glob(f"{opt_dir}/j*.json")):
    o = json.load(open(p))
    if 'csv' not in o or 'normally' not in str(o.get('termination')): continue
    cols = lambda c: c.split('.')[0] in ('x0', 'z_init', 'u') or c in ('lp__', 'K', 'amp', 'eps')
    r = pd.read_csv(o['csv'], comment='#', usecols=cols).iloc[-1]
    x0 = np.array([r[f'x0.{i+1}'] for i in range(nn)]); zi = np.array([r[f'z_init.{i+1}'] for i in range(nn)])
    u = np.array([r[f'u.{j+1}'] for j in range(ns)])
    x = simulate(x0, zi, r['K']); yh = (r['amp'] * (gain @ x)).T + u
    res = (logObs - yh)[LIK]; r2 = 1 - (res ** 2).sum() / ((logObs[LIK] - logObs[LIK].mean()) ** 2).sum()
    on = np.array([np.argmax(x[i] > 0) if (x[i] > 0).any() else 200 for i in range(nn)], float)
    ev = -np.log(((on - on.min()) + 1) / 20.); ev = (ev - ev.min()) / (ev.max() - ev.min()) if ev.max() > ev.min() else np.zeros(nn)
    order = np.argsort(-x0)
    ev_order = np.lexsort((-x0, -ev))
    rows.append(dict(job=o['job'], seed=o['seed'], lp=o['lp__'], iterations=o.get('iterations'), K=r['K'], amp=r['amp'], eps=r['eps'],
                     R2_log_features=r2, O2_x0=x0[iO2], O2_rank_x0=int(np.where(order == iO2)[0][0]) + 1,
                     O2_EV=ev[iO2], O2_rank_EV=int(np.where(ev_order == iO2)[0][0]) + 1, n_seizing=int((on < 200).sum()),
                     n_x0_gt_m2_05=int((x0 > -2.05).sum()),
                     top5_x0=";".join(f"{lut[i]}({x0[i]:.2f})" for i in order[:5]),
                     regions_x0_gt_m2_05=";".join(lut[i] for i in order if x0[i] > -2.05)))
df = pd.DataFrame(rows).sort_values('lp', ascending=False)
df.to_csv(out_csv, index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 90)
print(df[['job', 'lp', 'K', 'amp', 'R2_log_features', 'O2_x0', 'O2_rank_x0', 'O2_rank_EV', 'n_seizing', 'n_x0_gt_m2_05', 'top5_x0']].to_string(index=False))
# frequency with which each region is in the top-5 across optima
from collections import Counter
c = Counter(t.split('(')[0] for s in df.top5_x0 for t in s.split(';'))
print("top5 frequency across", len(df), "optima:", c.most_common(10))
