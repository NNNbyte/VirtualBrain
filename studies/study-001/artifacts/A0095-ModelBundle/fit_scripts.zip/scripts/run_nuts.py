"""Stage 2 of run_samplings_mcmc: NUTS chains initialised at the best L-BFGS optima
(vep_mcmc.create__jobs__sample__rpne_039: adapt delta=0.99, max_depth=7, 2 chains per init),
run with the GQ-free copy of vep_mcmc.stan (identical model block) directly via the CmdStan exe.
Usage: python run_nuts.py <n_best> <chains_per_init> <num_warmup> <num_samples> <seed>
"""
import sys, os, json, glob, subprocess, time
import numpy as np, pandas as pd
sys.path.insert(0, ".tools"); import stan_env
W = "studies/study-001/work/T0026"
n_best, cpi, nw, nsmp, seed = map(int, sys.argv[1:6])
opt = [json.load(open(p)) for p in sorted(glob.glob(f"{W}/out/opt/j*.json"))]
opt = [o for o in opt if 'lp__' in o and np.isfinite(o['lp__'])]
opt.sort(key=lambda o: -o['lp__'])
best = opt[:n_best]
OUT = f"{W}/out/nuts"; os.makedirs(OUT, exist_ok=True)
D = json.load(open(f"{W}/out/feat/datafeatures.json")); nn, ns = D['nn'], D['ns']
procs = []; manifest = []
for b, o in enumerate(best):
    df = pd.read_csv(o['csv'], comment='#'); r = df.iloc[-1]
    init = {'x0_star': [r[f'x0_star.{i+1}'] for i in range(nn)],
            'z_init_star': [r[f'z_init_star.{i+1}'] for i in range(nn)],
            'K_star': r['K_star'], 'amp_star': r['amp_star'],
            'u_star': [r[f'u_star.{j+1}'] for j in range(ns)], 'log_eps_sq': r['log_eps_sq']}
    # L-BFGS optima printed at 6-8 sig. digits can sit exactly on a bound (K_star=-1, amp_star=0) => log(0) at init;
    # nudge into the interior by 1e-8 (first launch failed for 4 chains because of this).
    init['K_star'] = max(init['K_star'], -1 + 1e-8); init['amp_star'] = max(init['amp_star'], 1e-8)
    ip = f"{OUT}/init_b{b}_optjob{o['job']}.json"; json.dump(init, open(ip, 'w'))
    for c in range(cpi):
        cid = b * cpi + c + 1
        csv = f"{OUT}/chain{cid}.csv"
        cmd = [os.path.abspath(f"{W}/stan/vep_mcmc_nogq.exe"), f"id={cid}", "sample", "save_warmup=0",
               f"num_warmup={nw}", f"num_samples={nsmp}", "adapt", "delta=0.99", "algorithm=hmc", "engine=nuts",
               "max_depth=7", "random", f"seed={seed}", "data", f"file={W}/out/feat/datafeatures.json",
               f"init={ip}", "output", f"file={csv}", "refresh=1"]
        log = open(f"{OUT}/chain{cid}.log", "w")
        procs.append(subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT))
        manifest.append(dict(chain_id=cid, init_from_opt_job=o['job'], init_opt_lp=o['lp__'], seed=seed, cmd=" ".join(cmd)))
json.dump(manifest, open(f"{OUT}/manifest.json", "w"), indent=1)
t = time.time()
for p in procs: p.wait()
print("NUTS done", round(time.time() - t), "s; return codes", [p.returncode for p in procs])
