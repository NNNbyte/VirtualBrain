import numpy as np, sys
d=np.load(sys.argv[1]); s=d['seeg']; n=list(d['ch_names'])
cm=-(s-s.mean(0))
for ch in ["GL'5-6","GL'11-12","CU'6-7","PFG'1-2","PI'8-9","TB'7-8","PP'3-4"]:
    i=n.index(ch); x=s[i]; c=cm[i]
    print(ch.ljust(9),'mean/std', ' '.join(f'{x[k:k+100].mean():+.2f}/{x[k:k+100].std():.3f}' for k in range(0,1500,100)))
    print(' '*9,'diffabs ', ' '.join(f'{np.abs(np.diff(c[k:k+100])).mean():.4f}' for k in range(0,1500,100)))
