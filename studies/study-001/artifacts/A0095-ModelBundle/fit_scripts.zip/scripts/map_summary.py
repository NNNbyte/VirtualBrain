import json, glob, numpy as np, pandas as pd
W="studies/study-001/work/T0026"
import sys
OPT=sys.argv[1] if len(sys.argv)>1 else f"{W}/out/opt"
lut=[l.split()[1] for l in open(".venv-model/Lib/site-packages/vep_stim/core/util/data/VepMrtrixLut.txt") if l.strip() and not l.startswith('#')][1:]
rows=[]
for p in sorted(glob.glob(f"{OPT}/j*.json")):
    o=json.load(open(p))
    if 'csv' not in o: continue
    df=pd.read_csv(o['csv'],comment='#',usecols=lambda c: c.startswith('x0.') or c in('lp__','K','amp','eps'))
    r=df.iloc[-1]; x0=np.array([r[f'x0.{i+1}'] for i in range(162)])
    order=np.argsort(-x0); rk=int(np.where(order==lut.index('Left-O2'))[0][0])+1
    conv='normally' in str(o.get('termination'))
    rows.append(dict(job=o['job'],lp=o['lp__'],conv=conv,iters=o.get('iterations'),K=round(r['K'],3),eps=round(r['eps'],4),O2_x0=round(x0[lut.index('Left-O2')],3),O2_rank=rk,
      n_gt_205=int((x0>-2.05).sum()),top3=[f"{lut[i]}:{x0[i]:.2f}" for i in order[:3]]))
rows.sort(key=lambda r:-r['lp'])
for r in rows: print(r)
json.dump(rows,open(f"{OPT}/map_table.json","w"),indent=1)
