"""Restart NUTS chains whose init sat exactly on a constraint boundary (K_star=-1 or amp_star=0 printed by
L-BFGS at 6-8 significant digits => log(0) at init). Nudge into the interior by 1e-8; otherwise identical command."""
import json, subprocess, sys
sys.path.insert(0, ".tools"); import stan_env  # PATH for TBB/mingw DLLs
W = "studies/study-001/work/T0026"; OUT = f"{W}/out/nuts"
man = json.load(open(f"{OUT}/manifest.json")); procs = []
for m in man:
    if m['chain_id'] not in [int(x) for x in sys.argv[1:]]: continue
    cmd = m['cmd'].split(" ")
    ip = [c for c in cmd if c.startswith("init=")][0][5:]
    d = json.load(open(ip)); d['K_star'] = max(d['K_star'], -1 + 1e-8); d['amp_star'] = max(d['amp_star'], 1e-8)
    ip2 = ip.replace(".json", "_nudged.json"); json.dump(d, open(ip2, "w"))
    cmd = [c if not c.startswith("init=") else "init=" + ip2 for c in cmd]
    m['cmd'] = " ".join(cmd); m['init_nudged'] = "K_star>=-1+1e-8, amp_star>=1e-8"
    procs.append(subprocess.Popen(cmd, stdout=open(f"{OUT}/chain{m['chain_id']}.log", "w"), stderr=subprocess.STDOUT))
json.dump(man, open(f"{OUT}/manifest.json", "w"), indent=1)
for p in procs: p.wait()
print("restarted chains done", [p.returncode for p in procs])
