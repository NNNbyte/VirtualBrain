"""Reproduce examples/run_samplings_mcmc.ipynb cells 7-14 (vep-stim @5367ef4) on
P1_SEEG_SEEG_fit.npz, with a FIXED numpy seed (the repo's np.random.normal calls are unseeded).
Usage: python prep_features.py <npz> <out_dir> <seed>
"""
import sys, os, json
import numpy as np
from vep_stim.core import vep_prepare_op
from vep_stim.stan import stan

npz, out_dir, seed = sys.argv[1], sys.argv[2], int(sys.argv[3])
os.makedirs(out_dir, exist_ok=True)
rng = np.random.RandomState(seed)   # replaces global unseeded np.random.normal

hpf, lpf, sfreq, n_samples = 10, 1, 250., 150   # notebook cell 5
d = np.load(npz, allow_pickle=False)
gain, tts, seeg, SC = d['gain'], d['time_steps'], d['seeg'], d['SC']

# notebook cell 8 (same operations, same order of RNG draws)
seg = seeg[:, 100:700]
seeg_4feature = -(seg - seg.mean(axis=0)) + rng.normal(0, 0.2, size=len(seg.T))
seeg_4feature = np.concatenate([rng.normal(0, 0.2, size=[len(seeg), 300]), seeg_4feature,
                                rng.normal(0, 0.2, size=[len(seeg), 200])], axis=1)
data = vep_prepare_op.prepare_data_feature_op(SC, seeg_4feature.T, gain, sfreq, hpf, lpf)

# cell 9
data_features = data['slp']
ds_freq = int(data_features.shape[0] / n_samples)
dfr = data_features[0:-1:ds_freq] - np.min(data_features)
dfr_t = np.arange(np.shape(dfr)[0])
# cell 13
dfr = dfr - np.min(dfr) + 1
assert np.all(dfr > 0)
# cell 14
U, s, Vh = np.linalg.svd(gain)
eig = Vh.T
rd = {'ns': gain.shape[0], 'nn': gain.shape[1], 'nt': dfr_t.size, 'Obs': dfr, 'SC': SC,
      'gain': gain, 'eig': eig}
stan.rdump(os.path.join(out_dir, 'P1_SEEG_SEEG_fit_hpf10_lpf1__datafeatures.R'), rd)
with open(os.path.join(out_dir, 'datafeatures.json'), 'w') as f:
    json.dump({k: (v.tolist() if isinstance(v, np.ndarray) else v) for k, v in rd.items()}, f)
np.save(os.path.join(out_dir, 'Obs.npy'), dfr)
meta = dict(npz=os.path.basename(npz), seed=seed, hpf=hpf, lpf=lpf, sfreq_assumed=sfreq,
            n_samples=n_samples, ds_freq=ds_freq, crop='seeg[:,100:700]', pad='300 pre/200 post N(0,0.2)',
            nt=int(dfr_t.size), ns=int(gain.shape[0]), nn=int(gain.shape[1]),
            Obs_min=float(dfr.min()), Obs_max=float(dfr.max()),
            time_steps_first_last=[float(tts[0]), float(tts[-1])],
            note='time_steps spacing 10 (ms per TVB monitor) => 100 Hz, but notebook uses sfreq=250 for filter design; reproduced as-is')
json.dump(meta, open(os.path.join(out_dir, 'features_meta.json'), 'w'), indent=1)
print(json.dumps(meta, indent=1))
