"""Stage 1 of run_samplings_mcmc: repeated L-BFGS optimisation (vep_mcmc.create__jobs__optimize__rpne_039
settings: algorithm=lbfgs tol_param=1e-10 iter=20000 init=5), run via cmdstanpy instead of GNU parallel.
Usage: python run_opt.py <n_runs> <n_parallel> <seed0> [feat_dir] [out_dir]
"""
import sys, os, time, json, glob, re
sys.path.insert(0, ".tools"); import stan_env
import cmdstanpy
from concurrent.futures import ThreadPoolExecutor
cmdstanpy.set_cmdstan_path(os.environ["CMDSTAN"])
W = "studies/study-001/work/T0026"
n_runs, n_par, seed0 = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
m = cmdstanpy.CmdStanModel(exe_file=f"{W}/stan/vep_mcmc.exe")
FEAT = sys.argv[4] if len(sys.argv) > 4 else f"{W}/out/feat"
OUT = sys.argv[5] if len(sys.argv) > 5 else f"{W}/out/opt"
data = f"{FEAT}/datafeatures.json"
os.makedirs(OUT, exist_ok=True)


def one(j):
    seed = seed0 + j
    od = f"{OUT}/j{j:02d}"
    t = time.time()
    rec = dict(job=j, seed=seed)
    try:
        f = m.optimize(data=data, algorithm="lbfgs", tol_param=1e-10, iter=20000, inits=5, seed=seed,
                       output_dir=od, require_converged=False, show_console=False, refresh=100)
        rec["lp__"] = float(f.optimized_params_dict["lp__"])
        rec["converged"] = bool(f.converged) if hasattr(f, "converged") else None
        # parse stdout for termination message / iterations
        txt = ""
        for p in glob.glob(f"{od}/*stdout*.txt"):
            txt += open(p, errors="ignore").read()
        msg = re.findall(r"(Optimization terminated[^\n]*\n[^\n]*|Convergence detected[^\n]*|Line search failed[^\n]*|Maximum number of iterations hit[^\n]*)", txt)
        rec["termination"] = msg[-2:] if msg else None
        its = re.findall(r"^\s+(\d+)\s+-?[\d.e+]+\s", txt, flags=re.M)
        rec["iterations"] = int(its[-1]) if its else None
        rec["csv"] = f.runset.csv_files[0]
    except Exception as e:
        rec["error"] = repr(e)[:500]
    rec["seconds"] = round(time.time() - t, 1)
    with open(f"{OUT}/j{j:02d}.json", "w") as fh:
        json.dump(rec, fh)
    print(json.dumps(rec), flush=True)
    return rec


with ThreadPoolExecutor(n_par) as ex:
    res = list(ex.map(one, range(n_runs)))
json.dump(res, open(f"{OUT}/summary.json", "w"), indent=1)
print("DONE")
