import sys, os, time
sys.path.insert(0, ".tools"); import stan_env
import cmdstanpy
cmdstanpy.set_cmdstan_path(os.environ["CMDSTAN"])
W="studies/study-001/work/T0026"
m = cmdstanpy.CmdStanModel(exe_file=f"{W}/stan/vep_mcmc.exe")
t=time.time()
f = m.optimize(data=f"{W}/out/feat/datafeatures.json", algorithm="lbfgs", tol_param=1e-10, iter=int(sys.argv[1]), inits=5, seed=1, output_dir=f"{W}/out/timing", require_converged=False, show_console=False)
print("elapsed", time.time()-t)
print(f.optimized_params_dict['lp__'])
