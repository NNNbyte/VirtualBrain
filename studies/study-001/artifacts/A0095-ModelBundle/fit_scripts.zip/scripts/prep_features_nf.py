"""SENSITIVITY variant (deviation from run_samplings_mcmc), modelled on the 'stimulated-NF data' branch of
examples/run_samplings-mm_inference.ipynb: pad with the channel's own post-seizure baseline instead of
N(0,0.2) noise, reference each channel to its baseline mean (no common-average step), hpf=4, NO added noise.
Then the same downsampling/log-positivity steps as run_samplings_mcmc (vep_mcmc single-modality model).
Usage: python prep_features_nf.py <npz> <out_dir> <ind_on> <ind_off> <ind_bd>
"""
import sys, os, json
import numpy as np
from vep_stim.core import vep_prepare_op

npz, out_dir = sys.argv[1], sys.argv[2]
ON, OFF, BD = map(int, sys.argv[3:6])
os.makedirs(out_dir, exist_ok=True)
hpf, lpf, sfreq, n_samples = 4., 1., 250., 150
d = np.load(npz, allow_pickle=False)
gain, seeg, SC = d['gain'], d['seeg'], d['SC']
base = seeg[:, OFF:OFF + BD]
x = np.concatenate([base, seeg[:, ON:OFF + BD]], axis=1)
x = x.T - base.T.mean(axis=0)
data = vep_prepare_op.prepare_data_feature_op(SC, x, gain, sfreq, hpf, lpf)
df = data['slp'].copy()
# channel mask + floor as in run_samplings-mm_inference.ipynb cell 10 (threshold -12.4, offset -20)
mask = np.max(df, axis=0) > -12.4
df[:, ~mask] = -20.
df = np.maximum(df, -20.)
ds = int(df.shape[0] / n_samples)
dfr = df[0:-1:ds] - np.min(df)
dfr = dfr - np.min(dfr) + 1
U, s, Vh = np.linalg.svd(gain)
rd = {'ns': gain.shape[0], 'nn': gain.shape[1], 'nt': int(dfr.shape[0]), 'Obs': dfr.tolist(), 'SC': SC.tolist(),
      'gain': gain.tolist(), 'eig': Vh.T.tolist()}
json.dump(rd, open(os.path.join(out_dir, 'datafeatures.json'), 'w'))
np.save(os.path.join(out_dir, 'Obs.npy'), dfr)
meta = dict(variant='NF-adapted sensitivity (deviation)', ON=ON, OFF=OFF, BD=BD, hpf=hpf, lpf=lpf, sfreq_assumed=sfreq,
            added_noise=None, channel_mask_threshold=-12.4, n_channels_kept=int(mask.sum()), floor=-20, ds_freq=ds, nt=int(dfr.shape[0]))
json.dump(meta, open(os.path.join(out_dir, 'features_meta.json'), 'w'), indent=1)
r = dfr.max(0) - dfr.min(0); names = list(d['ch_names'])
print(meta); print('top-range channels', [(names[i], round(float(r[i]), 2)) for i in np.argsort(-r)[:12]])
