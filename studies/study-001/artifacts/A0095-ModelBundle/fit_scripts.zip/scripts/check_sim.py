import sys, json, numpy as np, pandas as pd, glob
W="studies/study-001/work/T0026"
D=json.load(open(f"{W}/out/feat/datafeatures.json")); nn,nt,ns=D['nn'],D['nt'],D['ns']; SC=np.array(D['SC']); gain=np.array(D['gain'])
p=glob.glob(sys.argv[1]+"/*.csv")[0]
df=pd.read_csv(p,comment='#')
r=df.iloc[-1]
x0=r[[f"x0.{i+1}" for i in range(nn)]].values; zi=r[[f"z_init.{i+1}" for i in range(nn)]].values
X=np.array([[r[f"x.{i+1}.{t+1}"] for t in range(nt)] for i in range(nn)])
xq=np.array([[r[f"xhat_q.{t+1}.{j+1}"] for j in range(ns)] for t in range(nt)])
dt,tau0,I1=0.1,15.0,3.1
x=np.empty((nn,nt)); z=np.empty((nn,nt)); x[:,0]=-1.98; z[:,0]=zi; rs=SC.sum(1)
for t in range(nt-1):
    xt,zt=x[:,t],z[:,t]; gx=SC@xt-rs*xt
    x[:,t+1]=xt+dt*(1-xt**3-2*xt**2-zt+I1); z[:,t+1]=zt+dt*(1/tau0)*(4*(xt-x0)-zt-r['K']*gx)
u=r[[f"u.{j+1}" for j in range(ns)]].values
yh=(r['amp']*(gain@x)).T+u
print("max|x_numpy - x_stan|", np.nanmax(np.abs(x-X)), " max|xhat diff|", np.nanmax(np.abs(yh-xq)), "finite", np.isfinite(X).all())
