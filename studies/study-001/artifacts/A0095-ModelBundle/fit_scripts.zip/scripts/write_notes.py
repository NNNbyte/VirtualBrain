import json
W = "studies/study-001/work/T0026"
notes = json.load(open(f"{W}/bundle_notes_static.json"))
notes["hypotheses_result"] = {
    "hypothesis_set": "A0079-NetworkHypothesisSet",
    "H1-O2 (documented truth Left-O2)": "NOT recovered. Pooled 8-chain posterior: Left-O2 rank 113/162 by x0 mean (x0 -3.10, sd 1.02 across modes), rank 8 by EV mean (0.15; authors' EV median 1.0). Only in the highest-lp mode (chains 1-2, from L-BFGS job 11) is O2 near the top: x0 -1.34, rank 4 by x0, rank 3 by EV, but with 16 regions above x0=-2.05 (15 false positives).",
    "H2 (O2 + occipital pole + lingual gyrus)": "Not supported: Left-Occipital-pole / Left-Lingual-gyrus never in the top-3 of any NUTS mode; Spearman(authors' EV medians, our EV means) over the authors' 10 regions = 0.39 (p=0.27).",
    "H3 (occipito-temporal)": "Ambiguous: Left-STS-posterior, Left-T2-posterior, Left-T3-posterior and Left-Anterior-occipital-sulcus recur among top regions in several modes, but mode-dependent.",
    "H4 (coverage artefact)": "Mixed: high-gain parietal regions (Left-Superior-parietal-lobule-P1, Left-Supramarginal-posterior, Left-Precuneus) lead some modes, and Left-Angular-gyrus (top-gain region) is top-ranked in 3/6 optima of the NF-adapted sensitivity run; Spearman(x0 mean, gain column sum) = -0.25 in the pooled primary posterior.",
    "H0 (non-identifiable)": "SUPPORTED. 11 converged L-BFGS optima and 4 sampled modes give different EZ sets with comparable fit (MAP R2 0.44-0.51; lp 23481-24699); chains never mix (R-hat up to 4.2); within-mode x0 sd 0.02-0.09 is spuriously narrow.",
    "competing_hypotheses_preserved": "All modes reported (MAP ensemble tables + per-chain summaries); none selected as 'the' EZ."}
notes["numerical_notes"] = [
    "L-BFGS (primary): 20 starts; 11 converged ('relative gradient magnitude below tolerance', 339-1671 iterations, 5-19 min each under 20-way parallel load), 2 line-search failures at iteration 1 (init=5 too wide), 7 terminated at ~20 min time box. amp sits at its lower bound 0.005 (amp_star=0) in 10/11 optima and K at its bound 0 (K_star=-1) in 2/11 including the best one.",
    "Gradient cost ~0.2 s single-process, ~0.6 s under load (162 nodes x 157 steps Euler loop with scalar autodiff).",
    "NUTS: adapted step sizes 3.8e-4 to 1.4e-3; treedepth hit max_depth=7 on 592/600 draws (mean 126 leapfrogs); accept_stat mean 0.95; 8 divergences (all in chain 6); 5615 s wall for 150 iterations/chain.",
    "Package quirk: Stan likelihood loop i in (10*ns+1):(nt*ns) over to_vector(log(Obs)) (column-major) excludes the first 10*163 elements = SEEG channels 1-10 (+3 time points of channel 11) entirely, rather than the first 10 time points.",
    "Feature quirk: run_samplings_mcmc pads with N(0,0.2) noise after common-average removal; channels with large DC offsets (PFG', PI', TB', PP') get step transients at pad boundaries that dominate their log-power features; the in-window noise is ONE 600-sample vector broadcast to all channels.",
    "Sampling-rate quirk: filters designed with sfreq=250 while time_steps spacing implies 100 Hz (10 ms TVB monitor period)."]
notes["convergence"] = {
    "criterion": "R-hat < 1.05 (task acceptance) or optimizer converged",
    "optimizer": "PASS per run (11/11 non-failed finished runs converged by CmdStan criteria) but FAIL as an estimator: optima disagree on the EZ (multimodality).",
    "nuts_rhat": "FAIL: rank-normalised split R-hat for all 162 x0 > 1.05 (max 4.19, median 2.77); lp__ R-hat 3.52; CmdStan stansummary concurs (attached stansummary.csv).",
    "nuts_ess": "FAIL: bulk ESS for x0 8.6-~10 from 600 draws.",
    "divergences": "8/600 (chain 6 only).",
    "treedepth": "saturated (592/600 at max_depth 7) => inefficient exploration.",
    "caveat": "short run (75 warmup/75 samples vs package 500/500), but each chain pair stays in the distinct L-BFGS mode it started from (lp levels 23971-24502), so a longer run is unlikely to fix mixing without reparameterisation/tempering.",
    "overall": "NOT CONVERGED"}
notes["ppc_note"] = "In-sample PPC on the log envelope features of the single simulated seizure (no held-out presurgical seizure exists): pooled R2 0.51, RMSE 0.084 (eps 0.086), 90% predictive-interval coverage 0.92, median per-channel correlation 0.72 (0.80 for the 20 most variable channels). All modes fit about equally well (MAP R2 0.44-0.51), so the PPC cannot discriminate EZ hypotheses. NF-adapted sensitivity features: MAP R2 0.80-0.81 for all optima, again with different EZ sets."
notes["recovery_verdict"] = {
    "truth_used": "Left-O2 (documented: paper Fig. 3/5 'ground-truth left O2'; exact simulation x0 for P1 NOT documented in repo - Sim notebooks are configured for Patient2)",
    "pooled_posterior": {"rank_O2_by_x0_mean": 113, "rank_O2_by_EV_mean": 8,
                         "P_x0_O2_gt_-2.05": "0.25 (= 2 of 8 chains; chains do not mix, so this is a mode count, not a probability)",
                         "regions_with_P_gt_0.5": 0},
    "best_lp_mode": {"chains": "1-2 (L-BFGS job 11, lp ~24500)", "rank_O2_by_x0": 4, "rank_O2_by_EV": 3, "O2_x0": -1.34,
                     "n_regions_x0_gt_-2.05": 16, "false_positives": 15},
    "other_modes": "O2 rank 149-159 by x0 in chains 3-8 and in 10/11 MAP optima",
    "sensitivity_NF_adapted": "MAP-only, 6 optima: O2 rank 2 in one optimum (lp 17 below best), rank 149-153 in the other five; best-lp optimum has Left-Angular-gyrus as its only supra-threshold region",
    "comparison_with_authors": "Authors' P1 SEEG-stim posterior (repo xlsx) has O2 EV=1.0 in all 2000 draws; not reproduced. Spearman over their 10 regions rho=0.39 (p=0.27).",
    "verdict": "FAIL - the published single-modality pipeline, run as documented on the repo's P1 SEEG-stim file with reduced compute, does not recover the documented EZ; the failure is multimodality/non-identifiability under this feature recipe, not a software crash."}
notes["identifiability"] = "Not identifiable at this data/feature resolution: separated x0 modes (lp gaps 30-500) with near-equal predictive fit; amp and K pinned to bounds in most optima (amp-x0 trade-off). 92/162 regions show >50% prior-variance contraction in pooled draws, mostly within-mode overconfidence."
notes["implications"] = [
    "Runnable on this Windows machine (CmdStan 2.40 via cmdstanpy) once the package's GNU-parallel/bash job builders are bypassed. Full package settings (50 L-BFGS + 16 chains x 1000 NUTS iterations) would need roughly 6-8 h wall on 22 cores per seizure, or a cluster.",
    "It did NOT reproduce the authors' recovery of Left-O2 on their own simulated P1 data. Before HUP use we need (a) the authors' exact P1 generating configuration and the feature settings actually used for Fig. 3, to rule out recipe mismatch; (b) better-posed inference (informative priors from SEEG onset channels, fewer free parameters, tempering or many more starts with mode weighting).",
    "HUP patients lack MRI/DWI connectome and patient gain: a template connectome (VEP atlas in template space) plus electrode-coordinate gain adds structural error on top of the non-identifiability seen here even with true patient SC/gain. Any HUP result must be labelled a template-connectome sensitivity analysis and first benchmarked on simulations generated WITH the template.",
    "Recommendation: do not use vep-stim posteriors as EZ evidence for HUP cases until a recovery benchmark passes (true EZ rank 1, R-hat < 1.05) on simulated data generated with the template connectome."]
notes["runtime"] = {"wall_clock_total": "~2 h 20 min (2026-11-01 00:48 EDT to ~02:10 EST)", "feature_extraction": "<10 s",
                    "compile": "~95 s per model", "lbfgs_primary": "~20 min (20 parallel)",
                    "lbfgs_sensitivity": "~15 min (10 parallel, overlapped)", "nuts_aborted_150_150": "~13 min before abort",
                    "nuts_75_75": "5615 s wall (8 parallel chains)", "analysis": "~2 min"}
json.dump(notes, open(f"{W}/bundle_notes.json", "w"), indent=1)
print("notes ok")
